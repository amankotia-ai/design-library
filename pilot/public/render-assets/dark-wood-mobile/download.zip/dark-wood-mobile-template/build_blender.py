"""One fixed-camera mobile template with projective UVs and exact notch mask.
Run with Blender --background --python build_blender.py.
"""
from pathlib import Path
import bpy,json,numpy as np
ROOT=Path(__file__).resolve().parent
meta=json.loads((ROOT/'template.json').read_text());W,H=meta['final_size']
for o in list(bpy.data.objects):bpy.data.objects.remove(o,do_unlink=True)
for s in list(bpy.data.scenes)[1:]:bpy.data.scenes.remove(s)
scene=bpy.data.scenes[0];scene.name='uds-mobile-dark-wood'
scene['type']='Fixed photograph with projective screen artwork, native mask and baked illumination; no recovered phone/wood geometry'
scene['source_url']=meta['source_url'];scene['source_media_index']=1
scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False;scene.cycles.pixel_filter_type='BOX'
scene.render.resolution_x=W;scene.render.resolution_y=H;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.render.filepath='//renders/uds-mobile-dark-wood.png'
scene.view_settings.view_transform='Standard';scene.view_settings.look='None'
camera=bpy.data.cameras.new('Native portrait camera');camera.type='ORTHO';camera.ortho_scale=10;camera.sensor_fit='HORIZONTAL'
cam=bpy.data.objects.new('CAMERA — keep fixed',camera);scene.collection.objects.link(cam);cam.location=(0,0,10);scene.camera=cam

def image(path,noncolor=False):
 i=bpy.data.images.load(str(ROOT/path));i.pack()
 if noncolor:i.colorspace_settings.name='Non-Color'
 return i

def mesh(name,corners,divisions=1,z=0,overdraw=0):
 A=[];b=[]
 for (u,v),(x,y) in zip([(0,0),(1,0),(1,1),(0,1)],corners):
  A.extend([[u,v,1,0,0,0,-u*x,-v*x],[0,0,0,u,v,1,-u*y,-v*y]]);b.extend([x,y])
 hom=np.append(np.linalg.solve(np.array(A,float),np.array(b,float)),1).reshape(3,3);verts=[];uv=[]
 for row in range(divisions+1):
  for col in range(divisions+1):
   u=-overdraw+(1+2*overdraw)*col/divisions;v=-overdraw+(1+2*overdraw)*row/divisions;p=hom@np.array([u,v,1]);x,y=p[:2]/p[2];verts.append(((x/W-.5)*10,(.5-y/H)*10*H/W,z));uv.append((u,1-v))
 faces=[]
 for row in range(divisions):
  for col in range(divisions):
   j=row*(divisions+1)+col;faces.append((j,j+1,j+divisions+2,j+divisions+1))
 m=bpy.data.meshes.new(name);m.from_pydata(verts,[],faces);m.update();layer=m.uv_layers.new(name='Projective screen UV')
 for poly in m.polygons:
  for li in poly.loop_indices:layer.data[li].uv=uv[m.loops[li].vertex_index]
 ob=bpy.data.objects.new(name,m);scene.collection.objects.link(ob);return ob

plate=image('blank-mobile.png');bgmat=bpy.data.materials.new('Packed blank photograph');bgmat.use_nodes=True;n=bgmat.node_tree.nodes;n.clear();l=bgmat.node_tree.links
t=n.new('ShaderNodeTexImage');t.image=plate;t.interpolation='Closest';em=n.new('ShaderNodeEmission');out=n.new('ShaderNodeOutputMaterial');l.new(t.outputs['Color'],em.inputs['Color']);l.new(em.outputs[0],out.inputs[0])
bg=mesh('PLATE — native original photograph',[(0,0),(W,0),(W,H),(0,H)],z=-.05);bg.data.materials.append(bgmat);bg.hide_select=True

mask=image('screen-mask.png',True);illum=image('screen-illumination.png');art=image('empty-artwork.png')
mat=bpy.data.materials.new('SCREEN — replace image, physical mask retained');mat.use_nodes=True;n=mat.node_tree.nodes;n.clear();l=mat.node_tree.links
coords=n.new('ShaderNodeTexCoord');coords.location=(-900,-200)
artnode=n.new('ShaderNodeTexImage');artnode.name='REPLACE_IMAGE';artnode.label='Load your full portrait screenshot here';artnode.image=art;artnode.extension='EXTEND';artnode.location=(-900,200)
mn=n.new('ShaderNodeTexImage');mn.name='SCREEN_MASK — retain notch';mn.image=mask;mn.extension='CLIP';mn.location=(-650,-200);l.new(coords.outputs['Window'],mn.inputs['Vector'])
light=n.new('ShaderNodeTexImage');light.name='BAKED_SCREEN_ILLUMINATION';light.image=illum;light.location=(-650,-450);l.new(coords.outputs['Window'],light.inputs['Vector'])
color=n.new('ShaderNodeMixRGB');color.blend_type='MULTIPLY';color.inputs[0].default_value=1;color.location=(-300,200);l.new(artnode.outputs['Color'],color.inputs[1]);l.new(light.outputs['Color'],color.inputs[2])
alpha=n.new('ShaderNodeMath');alpha.operation='MULTIPLY';alpha.location=(-300,-100);l.new(artnode.outputs['Alpha'],alpha.inputs[0]);l.new(mn.outputs['Color'],alpha.inputs[1])
em=n.new('ShaderNodeEmission');em.location=(-50,200);l.new(color.outputs[0],em.inputs['Color']);tr=n.new('ShaderNodeBsdfTransparent');tr.location=(-50,-100)
mix=n.new('ShaderNodeMixShader');mix.location=(200,100);l.new(alpha.outputs[0],mix.inputs[0]);l.new(tr.outputs[0],mix.inputs[1]);l.new(em.outputs[0],mix.inputs[2]);out=n.new('ShaderNodeOutputMaterial');out.location=(450,100);l.new(mix.outputs[0],out.inputs[0])
screen=mesh('ASSET — portrait product screen',meta['screen_quad'],divisions=48,z=.01,overdraw=.01);screen.data.materials.append(mat)
screen['artwork_canvas']='1170x2532 recommended portrait screenshot; keep the physical notch safe area empty';screen['usage']='Replace REPLACE_IMAGE only. Camera, MASK and illumination stay fixed. Check exact text/proportions/placement after replacing. The screen mesh is a camera-space projective surface, not complete phone geometry.'
ref=image('reference/first-image-original.jpg');ref.use_fake_user=True;ref['usage']='Original FIRST image only, preserved for review. Not used in the final background.'
notes=bpy.data.texts.new('START HERE');notes.write('Only the first mobile shot from the cited post. Native1200x1600 portrait3:4. Packed original/blank, exact notch/rounded-screen mask and baked screen illumination. Select ASSET screen and replace REPLACE_IMAGE with your portrait screenshot. Extension is clamped to prevent exposed edge strips. Keep camera, mask and physical phone fixed. Save a copy. Not full3D phone/table geometry or new lighting/viewpoint. See composition-notes.md and independent QA evidence. Blank deliverable has transparent screen artwork by default. UV checker is QA only, not another template.')
for screenui in bpy.data.screens:
 for area in screenui.areas:
  if area.type=='VIEW_3D':area.spaces.active.region_3d.view_perspective='CAMERA';area.spaces.active.shading.type='MATERIAL'
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'uds-mobile-template.blend'),compress=True)
scene.render.filepath=str(ROOT/'checks/blender-blank.png');bpy.ops.render.render(write_still=True)
artnode.image=image('checks/uv-checker.png');scene.render.filepath=str(ROOT/'checks/uv-placement-check-v2.png');bpy.ops.render.render(write_still=True)
print('Built one scene with one projective screen and physical notch mask. Saved template remains empty; checker was not saved into it.')
