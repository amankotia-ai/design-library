"""Preserve the first reference photograph outside its replaceable screen.
Use the built-in generated empty display as the replacement material only.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import numpy as np
import json,hashlib
ROOT=Path(__file__).resolve().parent

def component(photo,seed,minimum=145,delta=42):
 a=np.array(photo.convert('RGB')).astype(float);ok=(a.min(2)>minimum)&(a.max(2)-a.min(2)<delta)
 # The reddish wood cannot enter this neutral display component.
 m=Image.fromarray(np.uint8(ok)*255).copy();assert m.getpixel(seed)==255
 ImageDraw.floodfill(m,seed,128,thresh=0)
 return Image.fromarray(np.uint8(np.array(m)==128)*255)

def fill_internal_holes(mask):
 inv=Image.fromarray(255-np.array(mask)).copy();ImageDraw.floodfill(inv,(0,0),128)
 return Image.fromarray(np.uint8((np.array(mask)>0)|(np.array(inv)==255))*255)

def convex_outline(mask):
 a=np.array(mask)>0;inside=a.copy();inside[1:]&=a[:-1];inside[:-1]&=a[1:];inside[:,1:]&=a[:,:-1];inside[:,:-1]&=a[:,1:]
 yy,xx=np.where(a&~inside);points=sorted(set(zip(xx.tolist(),yy.tolist())))
 def cross(o,a,b):return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
 lower=[]
 for pt in points:
  while len(lower)>1 and cross(lower[-2],lower[-1],pt)<=0:lower.pop()
  lower.append(pt)
 upper=[]
 for pt in reversed(points):
  while len(upper)>1 and cross(upper[-2],upper[-1],pt)<=0:upper.pop()
  upper.append(pt)
 out=Image.new('L',mask.size);ImageDraw.Draw(out).polygon(lower[:-1]+upper[:-1],fill=255);return out

def fit_quad(mask,rough):
 a=np.array(mask)>0;inner=a.copy();inner[1:]&=a[:-1];inner[:-1]&=a[1:];inner[:,1:]&=a[:,:-1];inner[:,:-1]&=a[:,1:]
 yy,xx=np.where(a&~inner);boundary=np.column_stack([xx,yy]).astype(float);lines=[];rng=np.random.default_rng(2094456);diagnostics=[]
 for i in range(4):
  p=np.array(rough[i],float);q=np.array(rough[(i+1)%4],float);v=q-p;length=np.linalg.norm(v);v/=length;n=np.array([-v[1],v[0]]);rel=boundary-p;t=rel@v/length
  points=boundary[(t>.14)&(t<.86)&(np.abs(rel@n)<45)];assert len(points)>30,(i,len(points))
  best=None;score=0
  for _ in range(240):
   p1,p2=points[rng.choice(len(points),2,replace=False)];vv=p2-p1;ll=np.linalg.norm(vv)
   if ll<length*.2:continue
   nn=np.array([-vv[1],vv[0]])/ll;dd=-(nn@p1);keep=np.abs(points@nn+dd)<.75
   if keep.sum()>score:score=keep.sum();best=keep
  assert best is not None
  pts=points[best];center=pts.mean(0);_,_,V=np.linalg.svd(pts-center,full_matrices=False);nn=V[-1];dd=-(nn@center);lines.append((nn,dd));diagnostics.append({'edge':i,'inliers':len(pts),'rms_pixels':float(np.sqrt(np.mean((pts@nn+dd)**2)))})
 corners=[]
 for i in range(4):
  n1,d1=lines[(i-1)%4];n2,d2=lines[i];corners.append(np.linalg.solve(np.stack([n1,n2]),-np.array([d1,d2])).tolist())
 return corners,diagnostics

def main():
 original=Image.open(ROOT/'reference/first-image-original.jpg').convert('RGB');generated=Image.open(ROOT/'candidates/blank-imagegen-v1.png').convert('RGB')
 raw=component(original,(425,555));mask=fill_internal_holes(raw)
 # The lower rounded display is convex. Recover its outer envelope to fill
 # article glyph cuts connected to the bezel; keep the original upper notch.
 lower_outline=convex_outline(mask);a=np.array(mask);a[950:]=np.array(lower_outline)[950:];mask=Image.fromarray(a)
 rough=[(204,440),(590,267),(1034,1133),(645,1303)]
 source_q,source_fit=fit_quad(mask,rough)
 sx=generated.width/original.width;sy=generated.height/original.height
 genmask=fill_internal_holes(component(generated,(round(425*sx),round(555*sy))))
 gen_q,gen_fit=fit_quad(genmask,[(x*sx,y*sy) for x,y in rough])
 ss=2;A=[];b=[]
 for (x,y),(u,v) in zip(np.array(source_q)*ss,gen_q):
  A.extend([[x,y,1,0,0,0,-u*x,-u*y],[0,0,0,x,y,1,-v*x,-v*y]]);b.extend([u,v])
 coeff=np.linalg.solve(np.array(A),np.array(b))
 mapped=generated.transform((original.width*ss,original.height*ss),Image.Transform.PERSPECTIVE,coeff,Image.Resampling.BICUBIC).resize(original.size,Image.Resampling.LANCZOS)
 mask=mask.filter(ImageFilter.GaussianBlur(.30));mask.save(ROOT/'screen-mask.png')
 final=Image.composite(mapped,original,mask);final.save(ROOT/'blank-mobile.png')
 # Actual source-derived screen illumination is reusable for composited artwork.
 illumination=Image.new('RGB',original.size,'white');illumination.paste(final,(0,0),mask);illumination.save(ROOT/'screen-illumination.png')
 outline=original.copy();d=ImageDraw.Draw(outline);d.line([tuple(p) for p in source_q]+[tuple(source_q[0])],fill='#F22687',width=3);outline.save(ROOT/'screen-placement-guide.jpg',quality=95)
 footprint=np.array(mask.filter(ImageFilter.MaxFilter(5)))>0;diff=np.abs(np.array(final).astype(int)-np.array(original).astype(int));assert not np.any(diff[~footprint])
 spec={'id':'uds-mobile-dark-wood','title':'Notched phone on figured dark wood','source_url':'https://x.com/abduzeedo/status/2094456376550649944','source_media_index':1,'scope':'Only the first/mobile photo. Other post images were not downloaded or used.','original_size':list(original.size),'generated_edit_size':list(generated.size),'final_size':list(final.size),'artwork_size':[1170,2532],'screen_quad':source_q,'source_edge_fit':source_fit,'generated_screen_quad':gen_q,'generated_edge_fit':gen_fit,'screen_mask':'screen-mask.png','screen_illumination':'screen-illumination.png','final':'blank-mobile.png','method':'Built-in imagegen cleared display; only its empty screen is projectively remapped onto the original photograph. Original geometry, wood, cast shadow and notch remain outside the native fitted mask.','max_change_beyond_mask_aa':int(diff[~footprint].max()),'sha256':hashlib.sha256((ROOT/'blank-mobile.png').read_bytes()).hexdigest(),'type':'Fixed photographic plate with local screen replacement; not recovered full3D'}
 (ROOT/'template.json').write_text(json.dumps(spec,indent=2)+'\n')
 print('Built native1200x1600 blank; original pixels outside screen AA retained exactly. Screen quad:',source_q)

if __name__=='__main__':main()
