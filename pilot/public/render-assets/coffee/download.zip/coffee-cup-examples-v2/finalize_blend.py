"""Save portable paths and delivery notes without altering or re-rendering outputs."""
import bpy
from pathlib import Path
root=Path(__file__).resolve().parent
for img in bpy.data.images:
 if img.source=='FILE' and img.filepath:img.filepath=bpy.path.relpath(img.filepath,start=str(root))
for scene in bpy.data.scenes:
 scene.render.filepath='//'+scene.name.lower()+'-example.png'
notes=bpy.data.texts.get('START HERE')
notes.write('\nV2 FIT CORRECTION: each cup has independently measured side boundaries and an antialiased PAPER_BODY_OCCLUSION mask. Preserve that material node when replacing REPLACE_BRAND_ARTWORK. Transparent rendered ink is composited over the direct source photograph to keep all unprinted pixels unchanged. DAYBREAK print artwork is intentionally bounded at its navy wrap baseline. See README.md and qa/ for checks.\n')
bpy.ops.wm.save_as_mainfile(filepath=str(root/'coffee-cup-branding.blend'))
