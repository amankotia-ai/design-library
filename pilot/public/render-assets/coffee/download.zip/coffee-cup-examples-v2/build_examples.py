"""Render two branding examples on fitted curved cup label meshes in Blender.
The photograph remains fixed; only the branding is rendered on 3D UV surfaces.
"""
import bpy,math,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
FIT_DATA=json.loads((Path(__file__).resolve().parent/'cup-fits.json').read_text())
FITS=FIT_DATA['cups'];YS=FIT_DATA['y_knots']
def interp(y,xs):
    for j in range(len(YS)-1):
        if y<=YS[j+1]:
            t=(y-YS[j])/(YS[j+1]-YS[j]);return xs[j]*(1-t)+xs[j+1]*t
    return xs[-1]+(y-YS[-1])*(xs[-1]-xs[-2])/(YS[-1]-YS[-2])

ROOT=Path(__file__).resolve().parent
W,H=1672,941
S=W/10
for o in list(bpy.data.objects):bpy.data.objects.remove(o,do_unlink=True)
for s in list(bpy.data.scenes)[1:]:bpy.data.scenes.remove(s)
first=bpy.data.scenes[0]
photo=bpy.data.images.load(str(ROOT/'blank-shot.png'));photo.pack()

def material(name,art=None,cup_index=None):
    mat=bpy.data.materials.new(name);mat.use_nodes=True
    n=mat.node_tree.nodes;n.clear();l=mat.node_tree.links
    out=n.new('ShaderNodeOutputMaterial');out.location=(650,100)
    em=n.new('ShaderNodeEmission');em.location=(230,180)
    bg=n.new('ShaderNodeTexImage');bg.image=photo;bg.interpolation='Closest';bg.location=(-550,-150)
    if art is None:
        l.new(bg.outputs['Color'],em.inputs['Color']);l.new(em.outputs[0],out.inputs['Surface'])
    else:
        uv=n.new('ShaderNodeTexCoord');uv.location=(-800,-100)
        l.new(uv.outputs['Window'],bg.inputs['Vector'])
        image=bpy.data.images.load(str(ROOT/'artwork'/art));image.pack()
        tex=n.new('ShaderNodeTexImage');tex.name='REPLACE_BRAND_ARTWORK';tex.label='Replace with your transparent print artwork';tex.image=image;tex.extension='CLIP';tex.location=(-550,240)
        multiply=n.new('ShaderNodeMixRGB');multiply.blend_type='MULTIPLY';multiply.inputs[0].default_value=1;multiply.location=(-100,180)
        l.new(tex.outputs['Color'],multiply.inputs[1]);l.new(bg.outputs['Color'],multiply.inputs[2]);l.new(multiply.outputs[0],em.inputs['Color'])
        tr=n.new('ShaderNodeBsdfTransparent');tr.location=(220,-20)
        mix=n.new('ShaderNodeMixShader');mix.location=(440,100)
        clip=n.new('ShaderNodeTexImage');clip.name='PAPER_BODY_OCCLUSION';clip.label='Per-cup physical paper silhouette';clip.location=(-550,-430)
        clip.image=bpy.data.images.load(str(ROOT/'masks'/f'cup-{cup_index+1:02d}-paper.png'));clip.image.colorspace_settings.name='Non-Color';clip.image.pack();clip.extension='CLIP'
        l.new(uv.outputs['Window'],clip.inputs['Vector'])
        alpha=n.new('ShaderNodeMath');alpha.operation='MULTIPLY';alpha.location=(160,-190)
        l.new(tex.outputs['Alpha'],alpha.inputs[0]);l.new(clip.outputs['Color'],alpha.inputs[1])
        l.new(alpha.outputs[0],mix.inputs[0]);l.new(tr.outputs[0],mix.inputs[1]);l.new(em.outputs[0],mix.inputs[2]);l.new(mix.outputs[0],out.inputs['Surface'])
    return mat

def make_background(col):
    mesh=bpy.data.meshes.new('Photo plane')
    mesh.from_pydata([(-5,-H/S/2,-2),(5,-H/S/2,-2),(5,H/S/2,-2),(-5,H/S/2,-2)],[],[(0,1,2,3)]);mesh.update()
    uv=mesh.uv_layers.new(name='Photo UV')
    for data,co in zip(uv.data,[(0,0),(1,0),(1,1),(0,1)]):data.uv=co
    obj=bpy.data.objects.new('PLATE — fixed coffee shot',mesh);col.objects.link(obj);obj.data.materials.append(material('Original plate'));obj.hide_select=True

def cup_print(col,index,art):
    # Independently measured paper silhouettes, not a shared approximate frustum.
    # Projection follows the photo side boundaries while retaining a real curved
    # 3D front surface, depth, angle-based UV compression, and curved horizontal ink.
    fit=FITS[index]
    rows,columns=160,256
    verts=[];coords=[];faces=[]
    for j in range(rows+1):
        v=j/rows;base_y=578-405*v
        left,right=interp(base_y,fit['left']),interp(base_y,fit['right'])
        radius=(right-left)/2
        for i in range(columns+1):
            u=i/columns;theta=(u-0.5)*math.pi
            # Camera sees the lower front of each horizontal ring as an ellipse.
            py=base_y+radius*.20*math.cos(theta)
            actual_left=interp(py,fit['left'])-.65
            actual_right=interp(py,fit['right'])+.65
            px=(actual_left+actual_right)/2+(actual_right-actual_left)/2*math.sin(theta)
            x=(px-W/2)/S;y=(H/2-py)/S
            z=(-405*.20*v+radius*math.sqrt(.96)*math.cos(theta))/S
            verts.append((x,y,z));coords.append((u,v))
    for j in range(rows):
        for i in range(columns):
            a=j*(columns+1)+i;b=a+columns+1;faces.append((a,a+1,b+1,b))
    mesh=bpy.data.meshes.new('Tapered cup front — UV mapped');mesh.from_pydata(verts,[],faces);mesh.update()
    uv=mesh.uv_layers.new(name='BRAND PRINT UV')
    for poly in mesh.polygons:
        poly.use_smooth=True
        for li in poly.loop_indices:uv.data[li].uv=coords[mesh.loops[li].vertex_index]
    obj=bpy.data.objects.new(f'CUP {index+1} — curved brand wrap',mesh);col.objects.link(obj);obj.data.materials.append(material(art,art,index))
    obj['geometry']='Individually silhouette-fitted curved UV print surface with paper-body occlusion mask; not a complete modeled cup'
    obj['artwork_file']='//artwork/'+art
    obj['instructions']='Replace REPLACE_BRAND_ARTWORK. Front-half texture: u left-to-right around cup; v bottom-to-top. White outside the printed area should have alpha zero.'

for k,brand in enumerate(['field','daybreak']):
    sc=first if k==0 else bpy.data.scenes.new('DAYBREAK');sc.name=brand.upper();bpy.context.window.scene=sc
    sc.render.engine='CYCLES';sc.cycles.samples=256;sc.cycles.use_denoising=False;sc.cycles.pixel_filter_type='BOX'
    sc.render.resolution_x=W;sc.render.resolution_y=H;sc.render.resolution_percentage=100
    sc.render.image_settings.file_format='PNG';sc.render.image_settings.color_mode='RGB';sc.render.filepath='//'+brand+'-example.png'
    sc.view_settings.view_transform='Standard';sc.view_settings.look='None'
    sc['type']='Blender-rendered curved UV branding over the original fixed photograph; plate shading is preserved in the ink material'
    plate=bpy.data.collections.new('FIXED PHOTOGRAPH');sc.collection.children.link(plate)
    artwork=bpy.data.collections.new('EDITABLE CURVED CUP PRINTS');sc.collection.children.link(artwork)
    make_background(plate)
    # Preserve unprinted source pixels through direct compositor plate input.
    # The curved ink is the only rendered layer; this is a Blender composite,
    # not a post-render painted repair.
    for obj in plate.objects:obj.hide_render=True
    sc.render.film_transparent=True;sc.render.dither_intensity=0
    comp=bpy.data.node_groups.new(brand+' — fixed photograph + curved ink','CompositorNodeTree')
    sc.compositing_node_group=comp
    comp.interface.new_socket(name='Image',in_out='OUTPUT',socket_type='NodeSocketColor')
    cn=comp.nodes;cl=comp.links
    source=cn.new('CompositorNodeImage');source.image=photo;source.location=(-500,-100)
    ink=cn.new('CompositorNodeRLayers');ink.scene=sc;ink.location=(-500,180)
    over=cn.new('CompositorNodeAlphaOver');over.inputs['Factor'].default_value=1;over.location=(-100,100)
    cl.new(source.outputs['Image'],over.inputs['Background']);cl.new(ink.outputs['Image'],over.inputs['Foreground'])
    output=cn.new('NodeGroupOutput');output.location=(200,100);cl.new(over.outputs['Image'],output.inputs['Image'])
    data=bpy.data.cameras.new('Matched camera');data.type='ORTHO';data.sensor_fit='HORIZONTAL';data.ortho_scale=10
    cam=bpy.data.objects.new('CAMERA — preserve shot',data);plate.objects.link(cam);cam.location=(0,0,10);sc.camera=cam
    for i in range(3):cup_print(artwork,i,f'{brand}-{i+1:02d}.png')

notes=bpy.data.texts.new('START HERE');notes.write('''Two branding examples: FIELD and DAYBREAK (fictional demo identities).\n\nChoose the matching scene. Select a CUP curved brand wrap object, open its material,\nand replace REPLACE_BRAND_ARTWORK with your transparent print artwork.\nEach UV canvas maps around the visible front half of the tapered cup: left-to-right\nis angle around the cup, bottom-to-top is height. The artwork follows the curved mesh.\n\nThe source is a fixed photograph. Cup tops, ground and shadows remain in the image.\nThe ink shader multiplies artwork by the photographed white-paper illumination to\npreserve its shading. This is not a complete 360-degree cup model or a new lighting rig.\nKeep the camera fixed; build complete cup geometry for new views or relighting.\nAll textures and the source photograph are packed; external artwork files are also supplied.\n''')
notes.write('\nV2: per-cup measured side fitting, PAPER_BODY_OCCLUSION masks, direct photograph compositor, bounded DAYBREAK artwork. See README.md and qa/.\n')
bpy.context.window.scene=first
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            area.spaces.active.region_3d.view_perspective='CAMERA';area.spaces.active.shading.type='MATERIAL';area.spaces.active.overlay.show_overlays=False
for img in bpy.data.images:
    if img.source=='FILE' and img.filepath:img.filepath=bpy.path.relpath(img.filepath,start=str(ROOT))
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'coffee-cup-branding.blend'))
for sc in bpy.data.scenes:
    bpy.context.window.scene=sc;bpy.ops.render.render(write_still=True)
print('Rendered FIELD and DAYBREAK in Blender from the same shot.')
