"""Read-only pixel checks and enlarged crops of the actual Blender exports."""
from PIL import Image,ImageFilter
import numpy as np,json
from pathlib import Path
root=Path(__file__).resolve().parent;plate=np.asarray(Image.open(root/'blank-shot.png').convert('RGB'))
result={};union=np.maximum.reduce([np.asarray(Image.open(root/'masks'/f'cup-{i:02d}-paper.png')) for i in range(1,4)])
for name in ['daybreak','field']:
 image=Image.open(root/f'{name}-example.png').convert('RGB');arr=np.asarray(image);diff=np.abs(arr.astype(int)-plate.astype(int))
 outside=(union==0);safe_outside=np.asarray(Image.fromarray(union).filter(ImageFilter.MaxFilter(5)))==0;outside[:2,:]=False;outside[-2:,:]=False;outside[:,:2]=False;outside[:,-2:]=False
 result[name]={'size':list(image.size),'max_photo_diff_outside_mask':int(diff[outside].max()),'nonzero_photo_pixels_outside_mask':int(np.count_nonzero(np.max(diff,2)[outside])),'max_photo_diff_beyond_2px_mask_aa_footprint':int(diff[safe_outside].max()),'nonzero_photo_pixels_beyond_2px_mask_aa_footprint':int(np.count_nonzero(np.max(diff,2)[safe_outside])),'max_photo_diff_coffee_tops':int(diff[120:210,230:1455].max())}
 for i,(l,r) in enumerate([(258,603),(667,1012),(1085,1429)],1):
  image.crop((l,252,r,580)).resize(((r-l)*3,984)).save(root/'qa'/f'{name}-cup-{i:02d}-edges-3x.png')
  image.crop((l,480,r,575)).resize(((r-l)*4,380)).save(root/'qa'/f'{name}-cup-{i:02d}-lower-4x.png')
(root/'qa'/'pixel-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
