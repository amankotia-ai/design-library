"""Reopen saved blend, inspect editable assets, and render scratch reproducibility evidence."""
import bpy,json,hashlib
import numpy as np
from pathlib import Path
root=Path(__file__).resolve().parent
report={'blender':bpy.app.version_string,'scenes':{},'images':[]}
for image in bpy.data.images:
 if image.source=='FILE':report['images'].append({'name':image.name,'path':image.filepath,'packed':bool(image.packed_file)})
for scene in bpy.data.scenes:
 name=scene.name.lower();bpy.context.window.scene=scene
 meshes=[o for o in scene.objects if 'curved brand wrap' in o.name]
 target=root/'qa'/f'reopened-{name}.png';scene.render.filepath=str(target)
 bpy.ops.render.render(write_still=True)
 original=root/f'{name}-example.png'
 source_image=bpy.data.images.load(str(original),check_existing=False)
 scratch_image=bpy.data.images.load(str(target),check_existing=False)
 source_pixels=np.empty(len(source_image.pixels),dtype=np.float32);source_image.pixels.foreach_get(source_pixels)
 scratch_pixels=np.empty(len(scratch_image.pixels),dtype=np.float32);scratch_image.pixels.foreach_get(scratch_pixels)
 pixel_equal=bool(np.array_equal(source_pixels,scratch_pixels))
 report['scenes'][name]={'curved_uv_meshes':len(meshes),'vertices':[len(o.data.vertices) for o in meshes],'camera_type':scene.camera.data.type,'direct_photo_compositor':bool(scene.compositing_node_group),'scratch_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'final_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'scratch_png_identical':target.read_bytes()==original.read_bytes(),'scratch_pixels_identical':pixel_equal,'max_reopened_linear_pixel_diff':float(np.max(np.abs(source_pixels-scratch_pixels)))}
(root/'qa'/'saved-scene-verification.json').write_text(json.dumps(report,indent=2))
