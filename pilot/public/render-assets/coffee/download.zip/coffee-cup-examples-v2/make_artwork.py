"""Draw two fictional vector-style demo identities as editable print textures."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import math

ROOT=Path(__file__).resolve().parent/'artwork'
ROOT.mkdir(exist_ok=True)
SIZE=2048
SERIF='/System/Library/Fonts/Supplemental/Baskerville.ttc'
SANS='/System/Library/Fonts/Avenir Next.ttc'
BOLD='/System/Library/Fonts/Supplemental/Arial Black.ttf'

def center(draw,text,y,font,fill):
    box=draw.textbbox((0,0),text,font=font)
    draw.text(((SIZE-(box[2]-box[0]))/2,y-box[1]),text,font=font,fill=fill)

def tracked(draw,text,y,font,fill,space):
    widths=[draw.textlength(c,font=font) for c in text]
    x=(SIZE-sum(widths)-space*(len(text)-1))/2
    for c,width in zip(text,widths):
        draw.text((x,y),c,font=font,fill=fill);x+=width+space

names=['OAT LATTE','ESPRESSO','CAPPUCCINO']
forest=(24,68,49,255)
for i,name in enumerate(names,1):
    im=Image.new('RGBA',(SIZE,SIZE),(255,255,255,0));d=ImageDraw.Draw(im)
    # A tiny rising field emblem and a generous serif name.
    d.ellipse((892,405,1156,669),outline=forest,width=8)
    d.line([(1024,620),(1024,470)],fill=forest,width=8)
    d.arc((935,475,1025,585),90,270,fill=forest,width=8)
    d.arc((1023,450,1113,560),270,450,fill=forest,width=8)
    center(d,'FIELD',800,ImageFont.truetype(SERIF,330),forest)
    tracked(d,'EVERYDAY COFFEE',1130,ImageFont.truetype(SANS,54),forest,7)
    d.line([(780,1300),(1268,1300)],fill=forest,width=3)
    tracked(d,name,1370,ImageFont.truetype(SANS,48),forest,6)
    d.rectangle((0,1775,SIZE,1792),fill=forest)
    d.rectangle((0,1810,SIZE,1818),fill=forest) # Native-size continuous hairline coverage
    im.save(ROOT/f'field-{i:02d}.png')

palettes=[((247,190,61,255),(226,85,36,255)),((242,133,100,255),(186,54,37,255)),((164,205,211,255),(29,91,111,255))]
navy=(25,39,54,255)
for i,(base,accent) in enumerate(palettes,1):
    im=Image.new('RGBA',(SIZE,SIZE),(255,255,255,0));d=ImageDraw.Draw(im)
    d.rectangle((0,470,SIZE,1790),fill=base)
    # A cropped sunrise mark above a compact, bold wordmark.
    d.ellipse((860,640,1188,968),fill=accent)
    d.rectangle((830,817,1218,985),fill=base)
    for offset in [0,32,64]:d.line((855,827+offset,1193,827+offset),fill=accent,width=12)
    center(d,'DAYBREAK',1020,ImageFont.truetype(BOLD,186),navy)
    tracked(d,'GOOD COFFEE. GOOD DAY.',1275,ImageFont.truetype(SANS,45),navy,2)
    for x in range(-256,SIZE+256,512):
        d.ellipse((x,1530,x+512,1990),fill=accent)
    d.rectangle((0,1735,SIZE,1790),fill=navy)
    # Bound the print to the navy baseline: the repeat is cropped by the wrap.
    d.rectangle((0,1791,SIZE,SIZE),fill=(255,255,255,0))
    im.save(ROOT/f'daybreak-{i:02d}.png')

print('Created six artwork textures for two fictional demo brands.')
