"""Measured paper silhouettes for fixed-shot ink occlusion, never final-image retouching.
All coordinates are native plate pixels. Each cup is independently traced.
"""
from pathlib import Path
import json, math
from PIL import Image, ImageDraw
ROOT=Path(__file__).resolve().parent
W,H=1672,941
YS=[210,240,270,300,340,380,420,460,500,520,540,560,574,578]
FITS=[
 dict(left=[264.5,269,273.5,278.2,284.5,290.5,296.7,303.1,309.2,312.3,315.3,318.3,320.4,321.8],right=[598,593.8,590.4,586.7,582,577.2,572.5,567.3,562.4,559.9,557.3,554.8,552.7,550.8],bottom_center=[436.3,602.0],bottom_sag=24),
 dict(left=[673,677,681.5,686,691.3,697,702.5,708,713.7,716.4,719.3,722,724,726],right=[1005,1001,997,992.7,987.7,982.3,976.7,971.3,965.9,963.3,960.5,957.6,955.3,953.5],bottom_center=[839.7,602.0],bottom_sag=24),
 dict(left=[1091,1095,1098.3,1102,1106.8,1111.5,1116.3,1121.3,1126.1,1128.6,1131.5,1134,1136,1138],right=[1422.5,1418.5,1414.2,1410,1404.1,1398.3,1391.8,1385.5,1379.2,1376.1,1373,1370,1367.8,1366.5],bottom_center=[1252.3,601.8],bottom_sag=23.8)
]
def interp(y,xs):
 for j in range(len(YS)-1):
  if y<=YS[j+1]:
   t=(y-YS[j])/(YS[j+1]-YS[j]);return xs[j]*(1-t)+xs[j+1]*t
 return xs[-1]+(y-YS[-1])*(xs[-1]-xs[-2])/(YS[-1]-YS[-2])
(ROOT/'masks').mkdir(exist_ok=True)
for i,fit in enumerate(FITS,1):
 # Body mask excludes the rim and silhouette exterior; 4x rasterization gives
 # subpixel antialiasing without an erosive inset around full-bleed print.
 points=[(interp(y,fit['left']),y) for y in range(210,579)]
 l,r=fit['left'][-1],fit['right'][-1]
 for k in range(1,257):
  t=k/256;points.append((l+(r-l)*t,578+fit['bottom_sag']*math.sin(math.pi*t)**.65))
 points += [(interp(y,fit['right']),y) for y in range(577,209,-1)]
 scale=4;im=Image.new('L',(W*scale,H*scale));d=ImageDraw.Draw(im)
 d.polygon([(round(x*scale),round(y*scale)) for x,y in points],fill=255)
 im.resize((W,H),Image.Resampling.LANCZOS).save(ROOT/'masks'/f'cup-{i:02d}-paper.png')
(ROOT/'cup-fits.json').write_text(json.dumps(dict(plate=[W,H],y_knots=YS,cups=FITS),indent=2))
