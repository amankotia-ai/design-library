"""Native 3840x2160 hybrid reconstruction of the five accepted ASTER & OAK studies.
Typography and geometry are rendered afresh, never upscaled from a branded final.
Photographic paper/hand/background plates retain their 1672x941 detail limitation.
"""
from PIL import Image,ImageDraw,ImageFont,ImageFilter
import numpy as np,math,pathlib,json,hashlib,argparse
BASE=pathlib.Path(__file__).resolve().parent
W,H=3840,2160
S=W/1672; OY=(H-941*S)/2
PINE='#173C31';CREAM='#F0E9D9';CLAY='#C97951';INK='#16251E'
FONTS=pathlib.Path('/System/Library/Fonts/Supplemental')
for p in ['assets','finals','qa']:(BASE/p).mkdir(exist_ok=True)
def pt(p):return (p[0]*S,p[1]*S+OY)
def quad(q):return [pt(p) for p in q]
def font(size,serif=False,bold=False):return ImageFont.truetype(str(FONTS/('Baskerville.ttc' if serif else ('Arial Bold.ttf' if bold else 'Arial.ttf'))),round(size))
class Art:
 def __init__(self,w,h,scale=3,bg=PINE):
  self.s=scale;self.im=Image.new('RGBA',(round(w*scale),round(h*scale)),bg)
 def rect(self,box,c,r=0):
  b=tuple(v*self.s for v in box);d=ImageDraw.Draw(self.im)
  if r:d.rounded_rectangle(b,radius=r*self.s,fill=c)
  else:d.rectangle(b,fill=c)
 def line(self,points,c,width=1):ImageDraw.Draw(self.im).line([(x*self.s,y*self.s) for x,y in points],fill=c,width=max(1,round(width*self.s)))
 def text(self,p,t,size,c=CREAM,serif=False,anchor=None,bold=False):ImageDraw.Draw(self.im).text((p[0]*self.s,p[1]*self.s),t,font=font(size*self.s,serif,bold),fill=c,anchor=anchor)
 def mark(self,p,r,c=CREAM):
  x,y=p;d=ImageDraw.Draw(self.im)
  for i in range(8):
   a=i*math.pi/4;ux,uy=math.cos(a),math.sin(a);vx,vy=-uy,ux;half=.085*r
   points=[((x+ux*rr+vx*ww)*self.s,(y+uy*rr+vy*ww)*self.s) for rr,ww in [(.33*r,half),(.88*r,half),(.88*r,-half),(.33*r,-half)]];d.polygon(points,fill=c)
  d.ellipse(((x-.13*r)*self.s,(y-.13*r)*self.s,(x+.13*r)*self.s,(y+.13*r)*self.s),fill=c)
 def save(self,name):self.im.save(BASE/'assets'/name)

def make_cover():
 a=Art(1600,900,3,PINE);a.mark((360,450),230);a.text((730,295),'ASTER',102,serif=True);a.text((730,400),'& OAK',102,serif=True);a.text((735,580),'COFFEE + EVERYDAY GOODS',25);a.text((735,720),'A LITTLE ROOM FOR THE EVERYDAY.',21);a.save('brand-cover-hires.png');return a.im

def make_assets():
 cover=make_cover()
 for sku,col,flav in [('daily',PINE,'DAILY BLEND'),('slow',CLAY,'SLOW MORNING'),('after',INK,'AFTER HOURS')]:
  a=Art(1000,1300,3,col);a.mark((500,200),105);a.text((500,355),'ASTER & OAK',86,serif=True,anchor='mm');a.line([(100,455),(900,455)],CREAM,2);a.text((500,660),flav,48,anchor='mm');a.text((500,760),'COFFEE',30,anchor='mm');a.text((500,1100),'CONCEPT PACKAGING',24,anchor='mm');a.text((500,1150),'FICTIONAL BRAND / DESIGN STUDY',18,anchor='mm');a.save(f'label-{sku}-hires.png')
  a=Art(1000,1000,3,col);a.mark((500,220),110);a.text((500,400),'ASTER & OAK',85,serif=True,anchor='mm');a.line([(100,500),(900,500)],CREAM,2);a.text((500,650),flav,47,anchor='mm');a.text((500,740),'COFFEE',28,anchor='mm');a.text((500,878),'CONCEPT PACKAGING',21,anchor='mm');a.text((500,925),'FICTIONAL BRAND / DESIGN STUDY',17,anchor='mm');a.save(f'sachet-{sku}-hires.png')
 for bg,c,n in [(PINE,CREAM,'pine'),(CREAM,PINE,'cream')]:
  a=Art(800,800,3,bg);a.mark((400,400),250,c);a.save(f'avatar-{n}-hires.png')
 a=Art(800,1600,3,INK);a.rect((0,0,800,720),PINE);a.im.alpha_composite(cover.resize((2400,1350),Image.Resampling.LANCZOS),(0,210));av=Image.open(BASE/'assets/avatar-cream-hires.png').resize((630,630),Image.Resampling.LANCZOS);a.im.alpha_composite(av,(195,1800));a.rect((580,610,755,683),INK,35);a.text((668,646),'Follow',32,anchor='mm');a.text((65,890),'ASTER & OAK',61,serif=True);a.text((65,1010),'Coffee + everyday goods.',34);a.text((65,1100),'A little room for the everyday.',29);a.text((65,1320),'FICTIONAL BRAND',27);a.text((65,1385),'DESIGN STUDY',27);a.text((65,1520),'asterandoak.example',29);a.save('held-profile-front-hires.png')

# Perspective transform computes local bounding boxes to keep 4K native layers
# tractable. Source art is >=3x prior canvas size; output samples at2x native4K.
def warp_local(art,q,ss=2):
 q=np.array(q,float);x0=max(0,int(np.floor(q[:,0].min()))-3);y0=max(0,int(np.floor(q[:,1].min()))-3);x1=min(W,int(np.ceil(q[:,0].max()))+3);y1=min(H,int(np.ceil(q[:,1].max()))+3);size=(x1-x0,y1-y0)
 dst=(q-np.array([x0,y0]))*ss;w,h=art.size;src=np.array([(0,0),(w,0),(w,h),(0,h)],float);aa=[];bb=[]
 for (x,y),(u,v) in zip(dst,src):aa.extend([[x,y,1,0,0,0,-u*x,-u*y],[0,0,0,x,y,1,-v*x,-v*y]]);bb.extend([u,v])
 c=np.linalg.solve(np.array(aa),np.array(bb));layer=art.convert('RGBA').transform((size[0]*ss,size[1]*ss),Image.Transform.PERSPECTIVE,c,Image.Resampling.BICUBIC).resize(size,Image.Resampling.LANCZOS)
 return layer,(x0,y0,x1,y1)

def matte_print(base,art,q,occlusion=None,tone=None):
 layer,box=warp_local(art,q);arr=np.array(layer).astype(np.float32);orig=np.array(base.crop(box).convert('RGB')).astype(np.float32)
 if tone is None:arr[:,:,:3]*=np.clip(orig.mean(2)/245,.42,1.04)[:,:,None]
 else:arr[:,:,:3]*=tone
 if occlusion:
  mask=Image.new('L',(layer.width*2,layer.height*2));ImageDraw.Draw(mask).polygon([((x-box[0])*2,(y-box[1])*2) for x,y in occlusion],fill=255);mask=mask.resize(layer.size,Image.Resampling.LANCZOS)
  arr[:,:,3]*=(1-np.asarray(mask,dtype=np.float32)/255)
 lay=Image.fromarray(np.uint8(np.clip(arr,0,255)));base.alpha_composite(lay,(box[0],box[1]));return base

def photo_plate(name):
 im=Image.open(BASE/'inputs'/f'{name}-blank.png').convert('RGBA')
 # Uniform scale and central ~1.15 source-scaled-pixel crop, never independent stretching.
 return im.transform((W,H),Image.Transform.AFFINE,(1/S,0,0,0,1/S,-OY/S),Image.Resampling.BICUBIC)

SURFACES=[('daily',[(1214,-35),(1457,111),(1456,514),(1214,369)]),('after',[(27,260),(293,130),(298,560),(27,690)]),('slow',[(434,151),(680,294),(674,723),(427,579)]),('daily',[(986,439),(1256,315),(1258,748),(988,882)])]
FRONT=[(820,941),(817,894),(819,443),(863,308),(894,230),(1219,61),(1228,65),(1234,75),(1235,90),(1236,110),(1242,140),(1254,180),(1266,220),(1275,260),(1282,300),(1285,340),(1286,380),(1287,420),(1287,460),(1287,530),(1285,813),(959,941)]
def pouches():
 im=photo_plate('variety-pouches')
 for i,(sku,q) in enumerate(SURFACES):im=matte_print(im,Image.open(BASE/'assets'/f'label-{sku}-hires.png'),quad(q),quad(FRONT) if i==0 else None)
 return im

def sachets():
 im=photo_plate('variety-sachet-grid')
 for i,sku in enumerate(['daily','slow','after','after','daily','slow']):
  x=[317,674,1029][i%3];y=[120,521][i//3];q=[(x,y),(x+277,y),(x+277,y+285),(x,y+285)];im=matte_print(im,Image.open(BASE/'assets'/f'sachet-{sku}-hires.png'),quad(q))
 return im

def held():
 im=photo_plate('strivenet-held-profile');art=Image.open(BASE/'assets/held-profile-front-hires.png');layer,box=warp_local(art,quad([(676,151),(881,161),(929,597),(710,596)]));arr=np.array(layer,dtype=np.float32);arr[:,:,:3]*=.86
 curve=[]
 for t in np.linspace(0,1,200):
  p=(1-t)**3*np.array([698,551])+3*(1-t)**2*t*np.array([727,533])+3*(1-t)*t*t*np.array([738,565])+t**3*np.array([708,607]);curve.append(tuple(p))
 pts=quad([(630,565),(680,554)]+curve+[(680,628),(630,628)])
 mask=Image.new('L',(layer.width*2,layer.height*2));ImageDraw.Draw(mask).polygon([((x-box[0])*2,(y-box[1])*2) for x,y in pts],fill=255);mask=mask.resize(layer.size,Image.Resampling.LANCZOS).filter(ImageFilter.GaussianBlur(.45*S));arr[:,:,3]*=1-np.asarray(mask,dtype=np.float32)/255;im.alpha_composite(Image.fromarray(np.uint8(np.clip(arr,0,255))),(box[0],box[1]));return im

# Flat studies are rebuilt from code at2x4K, including every edge and glyph.
def flat_canvas(bg):return Art(1672,941,S*2,bg)
def finish_flat(a):return a.im.resize((W,round(941*S)),Image.Resampling.LANCZOS).crop((0,round(-OY),W,round(-OY)+H))
def cards():
 a=flat_canvas('#E0E0DF');a.rect((334,175,1335,217),'#101110');a.text((369,189),'ASTER & OAK',24,serif=True);a.line([(548,200),(789,200)],CLAY,3)
 a.rect((312,216,1358,726),'#101110');a.rect((331,231,1340,709),PINE);a.mark((584,474),180)
 a.text((858,324),'ASTER',88,serif=True);a.text((858,414),'& OAK',88,serif=True);a.text((862,546),'COFFEE + EVERYDAY GOODS',23);a.text((862,638),'A LITTLE ROOM FOR THE EVERYDAY.',18)
 return finish_flat(a)

def panels():
 a=flat_canvas('#FFFFFF');a.rect((39,34,823,902),'#000000',25);a.rect((849,34,1633,902),'#EBEBEB',25);a.mark((429,427),218);a.text((429,683),'ASTER & OAK',76,serif=True,anchor='mm')
 # Profile is native sharp graphic geometry, matching accepted layout.
 a.rect((1063,230,1424,723),'#FFFFFF',20)
 a.rect((1063,230,1424,499),PINE,20);a.rect((1063,480,1424,499),PINE)
 a.mark((1158,349),72);a.text((1250,278),'ASTER',43,serif=True);a.text((1250,322),'& OAK',43,serif=True);a.text((1239,384),'COFFEE + EVERYDAY GOODS',10);a.text((1229,443),'A LITTLE ROOM FOR THE EVERYDAY.',8)
 # White ring and circular avatar are rebuilt, not an upscaled generated icon.
 d=ImageDraw.Draw(a.im);s=a.s;d.ellipse(tuple(v*s for v in (1077,449,1177,549)),fill='#FFFFFF');d.ellipse(tuple(v*s for v in (1084,456,1170,542)),fill=PINE);a.mark((1127,499),34)
 a.text((1086,566),'ASTER & OAK',24,'#000000',bold=True);a.text((1086,598),'Coffee + everyday goods.',16,'#777777');a.text((1086,634),'Fictional brand / design study',17,'#000000')
 a.rect((1317,560,1407,591),PINE,16);a.text((1362,575),'Follow',17,anchor='mm',bold=True)
 # Small linked rings are intentional UI illustration, exact copy is separate.
 d=ImageDraw.Draw(a.im);d.arc(tuple(v*s for v in (1089,679,1101,689)),40,320,fill=PINE,width=round(1.6*s));d.arc(tuple(v*s for v in (1094,674,1106,685)),220,500,fill=PINE,width=round(1.6*s));a.text((1121,677),'asterandoak.example',17,'#000000')
 return finish_flat(a)

JOBS={'variety-pouches':pouches,'original-06-stacked-landscape-cards':cards,'variety-sachet-grid':sachets,'original-13-logo-and-profile-panels':panels,'strivenet-held-profile':held}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--only',choices=list(JOBS));ap.add_argument('--suffix',default='v1');args=ap.parse_args();make_assets();records=[]
 for name,fn in JOBS.items():
  if args.only and args.only!=name:continue
  im=fn().convert('RGB');assert im.size==(W,H);p=BASE/'finals'/f'{name}-4k-{args.suffix}.png';im.save(p);records.append({'id':name,'path':str(p.relative_to(BASE)),'dimensions':[W,H],'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'construction':'native code-native geometry and font rendering' if name.startswith('original-') else 'original photographic blank resampled + native high-resolution exact artwork reconstruction','photo_detail_native':[1672,941] if not name.startswith('original-') else None});print(name,im.size,flush=True)
 (BASE/f'render-manifest-{args.suffix}.json').write_text(json.dumps({'contract':{'size':[W,H],'ratio':'16:9','source_uniform_scale':S,'center_vertical_crop_pixels':-2*OY},'renderer':'Pillow/numpy; fresh native typography/vector-like primitives, local2x supersampled homographies','source_assets':'High-resolution artwork built afresh from original brand design formulas and native fonts. Prior branded PNGs are visual references only.','limitations':'Photographic pouch/sachet/hand detail comes from1672x941 blank plates resampled to4K; this does not recover new photo detail. Flat cards/panels are rebuilt geometry at4K.','files':records},indent=2))
if __name__=='__main__':main()
