import bpy
for image in bpy.data.images:
    if image.source == 'FILE' and not image.packed_file:
        try:
            image.reload()
        except RuntimeError as error:
            print(image.name, error)
print('Reloaded external artwork images')
