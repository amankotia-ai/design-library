"""Render every scene at preview resolution and check the asset graph."""
import bpy,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
qa=ROOT/'verification';qa.mkdir(exist_ok=True)
report=[]
for scene in bpy.data.scenes:
    bpy.context.window.scene=scene
    assert scene.camera,scene.name
    scene.render.resolution_x=640;scene.render.resolution_y=360
    scene.cycles.samples=8 if scene.name.startswith('3D-') else 1
    scene.cycles.use_denoising=False
    scene.render.filepath=str(qa/(scene.name+'.png'))
    bpy.ops.render.render(write_still=True)
    report.append({'scene':scene.name,'rendered':True,'objects':len(scene.objects),'type':scene.get('type')})
for mat in bpy.data.materials:
    if mat.name.startswith('ARTWORK'):
        img=mat.node_tree.nodes['REPLACE_IMAGE'].image
        assert img and Path(bpy.path.abspath(img.filepath)).exists(),mat.name
        assert img.size[0]>0 and img.size[1]>0,mat.name
        assert img.pixels[3]==0,mat.name+' is not empty'
# Exercise the artwork path on a representative surface, without changing the saved file.
scene=bpy.data.scenes['09-metal-lanyard-badge'];bpy.context.window.scene=scene
obj=next(o for o in scene.objects if o.name.startswith('ASSET — badge-logo'))
tex=obj.active_material.node_tree.nodes['REPLACE_IMAGE'];old=tex.image
test=bpy.data.images.new('QA temporary artwork',width=64,height=64,alpha=True)
test.generated_color=(1,0,1,1);tex.image=test
scene.render.filepath=str(qa/'test-artwork-insertion.png');bpy.ops.render.render(write_still=True)
tex.image=old
(qa/'report.json').write_text(json.dumps(report,indent=2))
print('VERIFIED',len(report),'scene renders and transparent artwork files; tested artwork insertion')
