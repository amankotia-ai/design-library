"""Build the reference-matched 2.5D scenes and optional editable 3D stages.
Run: blender -b --factory-startup --python build_blender.py
No external Blender add-ons or Python packages required.
"""
import bpy
import math
import json
from pathlib import Path
from mathutils import Vector, Matrix

ROOT = Path(__file__).resolve().parent
MANIFEST = json.loads((ROOT / 'manifest.json').read_text())
SLOTS = json.loads((ROOT / 'slots.json').read_text())
ASSETS = ROOT / 'assets'
ASSETS.mkdir(exist_ok=True)
W, H = 1920, 1080
SCALE = 192.0

for obj in list(bpy.data.objects):
    bpy.data.objects.remove(obj, do_unlink=True)
for sc in list(bpy.data.scenes)[1:]:
    bpy.data.scenes.remove(sc)
first_scene = bpy.data.scenes[0]


def activate(scene):
    bpy.context.window.scene = scene


def collection(scene, name):
    c = bpy.data.collections.new(name)
    scene.collection.children.link(c)
    return c


def link(obj, col):
    col.objects.link(obj)
    return obj


def scene_base(name, existing=None):
    s = existing or bpy.data.scenes.new(name)
    s.name = name
    activate(s)
    s.render.engine = 'CYCLES'
    s.cycles.samples = 32
    s.cycles.use_denoising = True
    s.render.resolution_x = W
    s.render.resolution_y = H
    s.render.resolution_percentage = 100
    s.render.image_settings.file_format = 'PNG'
    s.render.image_settings.color_mode = 'RGBA'
    s.render.film_transparent = False
    s.view_settings.view_transform = 'Standard'
    s.view_settings.look = 'None'
    s.view_settings.exposure = 0
    s.view_settings.gamma = 1
    s.world = bpy.data.worlds.new(name + ' World')
    s.world.use_nodes = True
    s.world.node_tree.nodes['Background'].inputs['Color'].default_value = (0.7, 0.7, 0.7, 1)
    s.world.node_tree.nodes['Background'].inputs['Strength'].default_value = 0.35
    s.render.filepath = '//renders/' + name + '.png'
    return s


def camera(scene, col, location=(0, 0, 10), target=(0, 0, 0), ortho=10):
    data = bpy.data.cameras.new('Camera')
    data.type = 'ORTHO' if ortho else 'PERSP'
    if ortho:
        data.ortho_scale = ortho
    else:
        data.lens = 55
    obj = link(bpy.data.objects.new('CAMERA — compose here', data), col)
    obj.location = location
    backward = (obj.location - Vector(target)).normalized()
    right = Vector((0, 1, 0)).cross(backward).normalized()
    upward = backward.cross(right).normalized()
    obj.rotation_euler = Matrix((right, upward, backward)).transposed().to_euler()
    scene.camera = obj
    return obj


def xy(px, py, z=0):
    return ((px-W/2)/SCALE, (H/2-py)/SCALE, z)


def linear_solve(a, b):
    # Solve the square-to-quadrilateral projective transform without numpy.
    n = len(b)
    m = [list(a[i]) + [b[i]] for i in range(n)]
    for i in range(n):
        k = max(range(i, n), key=lambda k: abs(m[k][i]))
        m[i], m[k] = m[k], m[i]
        div = m[i][i]
        if abs(div) < 1e-12:
            raise ValueError('Degenerate artwork quadrilateral')
        m[i] = [v/div for v in m[i]]
        for j in range(n):
            if j == i:
                continue
            t = m[j][i]
            m[j] = [m[j][k] - t*m[i][k] for k in range(n+1)]
    return [row[-1] for row in m]


def quad_mesh(name, quad, col, z=0, steps=1):
    # Quad ordered top-left, top-right, bottom-right, bottom-left.
    a, b = [], []
    for (u, v), (x, y) in zip([(0,0),(1,0),(1,1),(0,1)], quad):
        a.append([u,v,1,0,0,0,-x*u,-x*v]); b.append(x)
        a.append([0,0,0,u,v,1,-y*u,-y*v]); b.append(y)
    hh = linear_solve(a,b)
    vertices, coords, faces = [], [], []
    for j in range(steps+1):
        for i in range(steps+1):
            u, v = i/steps, j/steps
            d = hh[6]*u+hh[7]*v+1
            px = (hh[0]*u+hh[1]*v+hh[2])/d
            py = (hh[3]*u+hh[4]*v+hh[5])/d
            vertices.append(xy(px,py,z)); coords.append((u,1-v))
    for j in range(steps):
        for i in range(steps):
            k=j*(steps+1)+i
            faces.append((k,k+steps+1,k+steps+2,k+1))
    me=bpy.data.meshes.new(name+' mesh')
    me.from_pydata(vertices,[],faces);me.update()
    uv=me.uv_layers.new(name='Artwork UV')
    for p in me.polygons:
        for li in p.loop_indices:
            uv.data[li].uv=coords[me.loops[li].vertex_index]
    return link(bpy.data.objects.new(name,me),col)


def rect_quad(rect):
    x1,y1,x2,y2=rect
    return [(x1,y1),(x2,y1),(x2,y2),(x1,y2)]


def emission_material(name, image):
    m=bpy.data.materials.new(name);m.use_nodes=True
    n=m.node_tree.nodes;n.clear();l=m.node_tree.links
    out=n.new('ShaderNodeOutputMaterial');out.location=(400,0)
    em=n.new('ShaderNodeEmission');em.location=(180,0)
    tex=n.new('ShaderNodeTexImage');tex.image=image;tex.location=(-120,0)
    l.new(tex.outputs['Color'],em.inputs['Color']);l.new(em.outputs[0],out.inputs['Surface'])
    return m


def empty_image(filename, size):
    path=ASSETS/filename
    img=bpy.data.images.new(filename,width=size[0],height=size[1],alpha=True)
    img.generated_color=(1,1,1,0)
    img.filepath_raw=str(path);img.file_format='PNG'
    img.save()
    img.filepath='//assets/'+filename
    return img


def asset_material(name, size=(1024,1024), radius=0, circle=False):
    img=empty_image(name+'.png',size)
    m=bpy.data.materials.new('ARTWORK — '+name);m.use_nodes=True
    n=m.node_tree.nodes;n.clear();l=m.node_tree.links
    out=n.new('ShaderNodeOutputMaterial');out.location=(800,160)
    mix=n.new('ShaderNodeMixShader');mix.location=(580,160)
    transparent=n.new('ShaderNodeBsdfTransparent');transparent.location=(360,50)
    emission=n.new('ShaderNodeEmission');emission.location=(360,240)
    tex=n.new('ShaderNodeTexImage');tex.name='REPLACE_IMAGE';tex.label='OPEN YOUR ARTWORK HERE (PNG with alpha)'
    tex.image=img;tex.location=(-600,350);tex.extension='CLIP'
    l.new(tex.outputs['Color'],emission.inputs['Color'])
    alpha=tex.outputs['Alpha']
    # Analytic UV masks prevent full-bleed screen artwork crossing rounded corners.
    if radius or circle:
        uv=n.new('ShaderNodeTexCoord');uv.location=(-850,-150)
        sep=n.new('ShaderNodeSeparateXYZ');sep.location=(-650,-150)
        l.new(uv.outputs['UV'],sep.inputs[0])
        dist=[]
        for axis in ['X','Y']:
            sub=n.new('ShaderNodeMath');sub.operation='SUBTRACT';sub.inputs[1].default_value=0.5
            l.new(sep.outputs[axis],sub.inputs[0])
            ab=n.new('ShaderNodeMath');ab.operation='ABSOLUTE';l.new(sub.outputs[0],ab.inputs[0])
            if not circle:
                su=n.new('ShaderNodeMath');su.operation='SUBTRACT';su.inputs[1].default_value=0.5-radius;l.new(ab.outputs[0],su.inputs[0])
                ma=n.new('ShaderNodeMath');ma.operation='MAXIMUM';ma.inputs[1].default_value=0;l.new(su.outputs[0],ma.inputs[0]);ab=ma
            sq=n.new('ShaderNodeMath');sq.operation='MULTIPLY';l.new(ab.outputs[0],sq.inputs[0]);l.new(ab.outputs[0],sq.inputs[1]);dist.append(sq)
        add=n.new('ShaderNodeMath');add.operation='ADD';l.new(dist[0].outputs[0],add.inputs[0]);l.new(dist[1].outputs[0],add.inputs[1])
        lt=n.new('ShaderNodeMath');lt.operation='LESS_THAN';lt.inputs[1].default_value=0.25 if circle else radius*radius
        l.new(add.outputs[0],lt.inputs[0])
        mul=n.new('ShaderNodeMath');mul.operation='MULTIPLY';l.new(alpha,mul.inputs[0]);l.new(lt.outputs[0],mul.inputs[1]);alpha=mul.outputs[0]
    l.new(alpha,mix.inputs[0]);l.new(transparent.outputs[0],mix.inputs[1]);l.new(emission.outputs[0],mix.inputs[2]);l.new(mix.outputs[0],out.inputs['Surface'])
    return m, img


asset_index=[]
for i,item in enumerate(MANIFEST['layouts']):
    sid=item['id']
    s=scene_base(sid,first_scene if i==0 else None)
    s['type']='2.5D camera-matched image plate with editable transparent artwork surfaces'
    s['source_timestamp_seconds']=round(i*0.75,2)
    s['usage']='Keep the camera fixed. Select an ASSET object and replace REPLACE_IMAGE in its material.'
    locked=collection(s,'PLATE — keep camera fixed')
    assets=collection(s,'ASSETS — replace artwork here')
    rig=collection(s,'CAMERA')
    camera(s,rig)
    bg=bpy.data.images.load(str(ROOT/item['plate']),check_existing=True)
    bg.pack()
    plane=quad_mesh('BACKGROUND — generated blank plate',rect_quad((0,0,W,H)),locked,z=-0.05)
    plane.data.materials.append(emission_material(sid+' plate',bg))
    plane.hide_select=True
    for j,slot in enumerate(SLOTS[sid]):
        aid=sid+'__'+slot['name']
        mat,img=asset_material(aid,tuple(slot.get('size',(1024,1024))),slot.get('radius',0),slot.get('circle',False))
        obj=quad_mesh('ASSET — '+slot['name'],slot.get('quad') or rect_quad(slot['rect']),assets,z=0.01+j*0.002,steps=24 if 'quad' in slot else 1)
        obj.data.materials.append(mat)
        obj['asset_file']='//assets/'+aid+'.png'
        obj['instructions']='Shader Editor > REPLACE_IMAGE > Open. Transparent PNG recommended. Keep camera fixed for this scene.'
        obj.color=(0.1,0.8,0.5,0.3)
        asset_index.append({'scene':sid,'slot':slot['name'],'file':'assets/'+aid+'.png','size':list(img.size)})


# The five extra stages are real geometry and can be relit or reframed.
def pbr(name,color,metal=0,rough=0.4):
    m=bpy.data.materials.new(name);m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value=(*color,1)
    p.inputs['Metallic'].default_value=metal
    p.inputs['Roughness'].default_value=rough
    return m


metal=pbr('Brushed aluminum',(0.45,0.46,0.47),1,0.27)
dark=pbr('Black anodized metal',(0.035,0.037,0.04),0.8,0.27)
paper=pbr('Warm white insert',(0.91,0.90,0.87),0,0.56)
black=pbr('Black matte',(0.012,0.012,0.014),0.1,0.52)
ivory=pbr('Ivory ceramic icon',(0.84,0.86,0.88),0.15,0.25)
frost=pbr('Frosted tray',(0.48,0.56,0.60),0.25,0.3)


def round_points(w,h,r,n=12):
    pts=[]
    for cx,cy,angle in [(w/2-r,h/2-r,0),(-w/2+r,h/2-r,90),(-w/2+r,-h/2+r,180),(w/2-r,-h/2+r,270)]:
        for j in range(n+1):
            a=math.radians(angle+j*90/n)
            pts.append((cx+r*math.cos(a),cy+r*math.sin(a)))
    return pts


def rounded_slab(name,loc,w,h,depth,r,mat,col):
    pts=round_points(w,h,min(r,w/2-0.0001,h/2-0.0001))
    n=len(pts)
    verts=[(x,y,z) for z in [-depth/2,depth/2] for x,y in pts]
    faces=[tuple(reversed(range(n))),tuple(range(n,2*n))]
    faces += [(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    me=bpy.data.meshes.new(name+' mesh');me.from_pydata(verts,[],faces);me.update()
    # The perimeter is clockwise; recalculate outside normals before rendering.
    obj=link(bpy.data.objects.new(name,me),col);obj.location=loc
    obj.data.materials.append(mat)
    activate(bpy.context.scene)
    bpy.context.view_layer.objects.active=obj;obj.select_set(True)
    bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT')
    obj.select_set(False)
    be=obj.modifiers.new('Soft machined edge','BEVEL');be.width=min(0.025,depth*0.2);be.segments=3
    obj.modifiers.new('Weighted corner normals','WEIGHTED_NORMAL')
    return obj


def ring(name,loc,w,h,depth,r,band,mat,col):
    outer=round_points(w,h,r);inner=round_points(w-2*band,h-2*band,max(r-band,0.025))
    n=len(outer);verts=[]
    for z in [-depth/2,depth/2]:
        verts += [(x,y,z) for x,y in outer]+[(x,y,z) for x,y in inner]
    faces=[]
    for i in range(n):
        j=(i+1)%n
        faces += [(i,j,2*n+j,2*n+i),(n+j,n+i,3*n+i,3*n+j),(2*n+i,2*n+j,3*n+j,3*n+i),(j,i,n+i,n+j)]
    me=bpy.data.meshes.new(name+' mesh');me.from_pydata(verts,[],faces);me.update()
    ob=link(bpy.data.objects.new(name,me),col);ob.location=loc;ob.data.materials.append(mat)
    bpy.context.view_layer.objects.active=ob;ob.select_set(True)
    bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.normals_make_consistent(inside=False);bpy.ops.object.mode_set(mode='OBJECT');ob.select_set(False)
    be=ob.modifiers.new('Edge bevel','BEVEL');be.width=0.014;be.segments=3
    ob.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
    return ob


def light(col,name,loc,energy,size,target=(0,0,0),color=(1,1,1),shape='DISK'):
    d=bpy.data.lights.new(name,'AREA');d.energy=energy;d.shape=shape;d.size=size;d.color=color
    o=link(bpy.data.objects.new(name,d),col);o.location=loc
    o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()


def true_scene(name,bg=(0.62,0.62,0.62),ortho=10,loc=(0,0,12),target=(0,0,0)):
    s=scene_base(name);s['type']='Editable 3D approximation; original camera and source geometry are unavailable'
    s.view_settings.view_transform='AgX'
    col=collection(s,'GEOMETRY — editable');rig=collection(s,'LIGHTS AND CAMERA')
    camera(s,rig,loc,target,ortho)
    backdrop=rounded_slab('Studio backdrop',(0,0,-3),200,200,0.1,0.1,pbr(name+' background',bg,0,0.8),col)
    light(rig,'Key softbox',(-4,5,7),1000,5)
    light(rig,'Right strip',(5,1,4),650,3)
    light(rig,'Top rim',(0,7,0),800,3)
    return s,col,rig


def model_asset(scene,col,name,loc,w,h,size=(1024,1024),radius=0):
    mat,img=asset_material(scene.name+'__'+name,size,radius)
    ob=quad_mesh('ASSET — '+name,rect_quad((0,0,W,H)),col)
    # Reset the camera-space plane into a local front-facing physical rectangle.
    for v in ob.data.vertices:
        v.co.x=v.co.x/10*w;v.co.y=v.co.y/(H/SCALE)*h
    ob.location=loc;ob.data.materials.append(mat)
    ob['asset_file']='//assets/'+img.name
    asset_index.append({'scene':scene.name,'slot':name,'file':'assets/'+img.name,'size':list(img.size)})
    return ob


s,col,rig=true_scene('3D-01-metal-badge',ortho=8.8,loc=(1.2,0.2,12))
rounded_slab('Back casing',(0,-0.38,0),1.82,3.2,0.18,0.13,dark,col)
ring('Metal frame',(0,-0.38,0.13),1.80,3.2,0.13,0.13,0.12,metal,col)
rounded_slab('Paper insert',(0,-0.45,0.12),1.52,2.64,0.025,0.01,paper,col)
rounded_slab('Slot backing',(0,1.01,0.19),1.0,0.12,0.06,0.055,black,col)
strapmat=pbr('Woven black strap',(0.018,0.02,0.022),0,0.9)
n=strapmat.node_tree.nodes;l=strapmat.node_tree.links
noise=n.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=240;noise.inputs['Detail'].default_value=2
bump=n.new('ShaderNodeBump');bump.inputs['Strength'].default_value=0.45;bump.inputs['Distance'].default_value=0.015
l.new(noise.outputs['Fac'],bump.inputs['Height']);l.new(bump.outputs['Normal'],n['Principled BSDF'].inputs['Normal'])
rounded_slab('Fabric lanyard',(0,2.3,0.13),0.57,2.65,0.06,0.035,strapmat,col)
for x in [-0.75,0.75]:
    bpy.ops.mesh.primitive_uv_sphere_add(segments=16,ring_count=8,radius=0.04,location=(x,1.03,0.23))
    o=bpy.context.object;o.name='Corner screw';o.scale.z=0.3;o.data.materials.append(dark)
    for c in list(o.users_collection):c.objects.unlink(o)
    col.objects.link(o)
model_asset(s,col,'insert',(0,-0.45,0.141),1.51,2.63,(768,1344))

s,col,rig=true_scene('3D-02-app-dock',bg=(0.38,0.46,0.50),ortho=10)
rounded_slab('Frosted dock tray',(0,0,-0.22),7.3,2.8,0.18,0.65,frost,col)
for name,x,y,side in [('left',-2.35,-0.15,1.7),('center',0,0,2.05),('right',2.35,-0.18,1.66)]:
    rounded_slab('Blank icon '+name,(x,y,0.02),side,side,0.18,side*0.21,ivory,col)
    model_asset(s,col,'icon-'+name,(x,y,0.124),side*0.94,side*0.94,radius=0.17)

s,col,rig=true_scene('3D-03-stacked-cards',ortho=10)
rounded_slab('Rear landscape card',(0,0.20,0),6.0,2.95,0.04,0.005,black,col)
rounded_slab('Front landscape card',(0,-0.05,0.09),6.25,3.05,0.04,0.005,black,col)
model_asset(s,col,'front-card',(0,-0.05,0.116),6.25,3.05,(1536,752))

s,col,rig=true_scene('3D-04-tablet',bg=(0.68,0.68,0.68),ortho=10)
rounded_slab('Tablet aluminum body',(0,0,0),6.5,4.25,0.18,0.32,dark,col)
rounded_slab('Screen bezel',(0,0,0.10),6.4,4.15,0.025,0.29,black,col)
rounded_slab('Blank warm screen',(0,0,0.121),6.22,3.98,0.015,0.23,paper,col)
model_asset(s,col,'screen',(0,0,0.132),6.20,3.96,(1536,980),radius=0.055)

s,col,rig=true_scene('3D-05-metal-display-macro',bg=(0.001,0.001,0.001),ortho=6.1,loc=(3.6,2.3,9),target=(0.2,0.7,0))
# Place a large frame to the right; camera is intentionally cropped like the reference.
ring('Machined aluminum display frame',(1.75,-0.5,0.1),5.2,7.4,0.30,0.35,0.13,metal,col)
ring('Black inset gasket',(1.75,-0.5,0.18),4.94,7.14,0.07,0.25,0.09,black,col)
rounded_slab('Blank white display',(1.75,-0.5,0.17),4.76,6.96,0.07,0.20,paper,col)
rounded_slab('Top bracket',(-1.55,1.25,-0.7),3.6,0.6,0.25,0.12,metal,col)
rounded_slab('Lower bracket',(-1.55,-0.45,-0.7),3.6,0.6,0.25,0.12,dark,col)
for x in [-2.8,-0.2]:rounded_slab('Bracket column',(x,0.4,-0.75),0.28,1.6,0.3,0.08,dark,col)
curve=bpy.data.curves.new('Cable route','CURVE');curve.dimensions='3D';curve.bevel_depth=0.07;curve.bevel_resolution=5
sp=curve.splines.new('BEZIER');sp.bezier_points.add(3)
for bp,co in zip(sp.bezier_points,[(-0.6,1.1,-0.5),(-2.0,0.9,-0.5),(-2.0,-0.2,-0.5),(-0.5,-0.4,-0.5)]):
    bp.co=co;bp.handle_left_type='AUTO';bp.handle_right_type='AUTO'
cable=link(bpy.data.objects.new('Black cable loop',curve),col);curve.materials.append(strapmat)
model_asset(s,col,'display-logo',(0.75,1.35,0.213),1.3,1.3)


(ROOT/'asset-index.json').write_text(json.dumps(asset_index,indent=2))
instructions='''BLANK RENDER SHOWCASES\n\n14 reference-matched image-based scenes, followed by five optional real 3D stages.\nThe 2.5D scenes use imagegen PNG plates: keep their cameras fixed.\nThe 3D stages are approximations with editable geometry, cameras and lighting.\n\nTO ADD ARTWORK\n1. Pick a scene in the top-right Scene menu.\n2. Expand ASSETS in the Outliner. Select an ASSET object.\n3. Open the Shading workspace and find the REPLACE_IMAGE node.\n4. Open your PNG artwork there. Alpha determines what appears.\n5. Press F12 to render at 1920 x 1080.\n\nAlternative: replace the corresponding transparent PNG in assets/ and run\nreload_assets.py from this file's Text Editor. Every scene/slot/file is listed\nin asset-index.json. Replacements should keep the same aspect ratio.\n\nThe supplied artwork files are fully transparent by design. An empty render\nis the intended starting state. Select objects to see their surface outlines.\nBackground plates are packed; replacement images use relative paths.\n\nOriginal reference: https://x.com/byamine__/status/2115903370506723494\n'''
txt=bpy.data.texts.new('START HERE');txt.write(instructions)
reload_script="""import bpy\nfor image in bpy.data.images:\n    if image.source == 'FILE' and not image.packed_file:\n        try:\n            image.reload()\n        except RuntimeError as error:\n            print(image.name, error)\nprint('Reloaded external artwork images')\n"""
txt=bpy.data.texts.new('reload_assets.py');txt.write(reload_script)
(ROOT/'reload_assets.py').write_text(reload_script)
activate(bpy.data.scenes[MANIFEST['layouts'][0]['id']])
bpy.ops.object.select_all(action='DESELECT')
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            area.spaces.active.region_3d.view_perspective='CAMERA'
            area.spaces.active.shading.type='MATERIAL'
            area.spaces.active.overlay.show_overlays=False
            area.spaces.active.region_3d.view_camera_zoom=10
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'blank-showcases.blend'))
print('BUILT',len(bpy.data.scenes),'scenes;',len(asset_index),'artwork slots')
