"""Build seven packed fixed-camera scenes. Blender --background --python build_blender.py."""
from pathlib import Path
import bpy,json,numpy as np
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'manifest.json').read_text());(ROOT/'checks').mkdir(exist_ok=True)
for o in list(bpy.data.objects):bpy.data.objects.remove(o,do_unlink=True)
initial_scenes=list(bpy.data.scenes)
checks=[]
def image(path,noncolor=False):
 i=bpy.data.images.load(str(ROOT/path));i.pack();i.use_fake_user=True
 if noncolor:i.colorspace_settings.name='Non-Color'
 return i
def mesh(scene,name,corners,W,H,z=0,divisions=1,overdraw=0):
 A=[];b=[]
 for(u,v),(x,y)in zip([(0,0),(1,0),(1,1),(0,1)],corners):
  A.extend([[u,v,1,0,0,0,-u*x,-v*x],[0,0,0,u,v,1,-u*y,-v*y]]);b.extend([x,y])
 hom=np.append(np.linalg.solve(np.array(A,float),np.array(b,float)),1).reshape(3,3);verts=[];uv=[]
 for row in range(divisions+1):
  for col in range(divisions+1):
   u=-overdraw+(1+2*overdraw)*col/divisions;v=-overdraw+(1+2*overdraw)*row/divisions;p=hom@np.array([u,v,1]);x,y=p[:2]/p[2];verts.append(((x/W-.5)*10,(.5-y/H)*10*H/W,z));uv.append((u,1-v))
 faces=[]
 for row in range(divisions):
  for col in range(divisions):
   j=row*(divisions+1)+col;faces.append((j,j+1,j+divisions+2,j+divisions+1))
 m=bpy.data.meshes.new(name);m.from_pydata(verts,[],faces);m.update();layer=m.uv_layers.new(name='Projective artwork UV')
 for poly in m.polygons:
  for li in poly.loop_indices:layer.data[li].uv=uv[m.loops[li].vertex_index]
 ob=bpy.data.objects.new(name,m);scene.collection.objects.link(ob);return ob
for t in manifest['templates']:
 W,H=t['original_size'];folder=Path('templates')/t['id'];scene=bpy.data.scenes.new(t['id']);scene['template_type']=t['type'];scene['source_kind']='user_attachment'
 scene.render.engine='CYCLES';scene.cycles.samples=16;scene.cycles.use_denoising=False;scene.cycles.pixel_filter_type='BOX'
 scene.render.resolution_x=W;scene.render.resolution_y=H;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.render.filepath='//renders/'+t['id']+'.png';scene.view_settings.view_transform='Standard';scene.view_settings.look='None'
 camera=bpy.data.cameras.new(t['id']+' camera');camera.type='ORTHO';camera.ortho_scale=10;camera.sensor_fit='HORIZONTAL';cam=bpy.data.objects.new('CAMERA — keep fixed',camera);scene.collection.objects.link(cam);cam.location=(0,0,10);scene.camera=cam
 mat=bpy.data.materials.new(t['id']+' blank photograph');mat.use_nodes=True;n=mat.node_tree.nodes;n.clear();l=mat.node_tree.links;tex=n.new('ShaderNodeTexImage');tex.image=image(t['blank']);tex.interpolation='Closest';em=n.new('ShaderNodeEmission');out=n.new('ShaderNodeOutputMaterial');l.new(tex.outputs['Color'],em.inputs['Color']);l.new(em.outputs[0],out.inputs[0]);plate=mesh(scene,'PLATE — original physical photograph',[(0,0),(W,0),(W,H),(0,H)],W,H,z=-.05);plate.data.materials.append(mat);plate.hide_select=True
 image(t['original'])
 for index,s in enumerate(t['slots']):
  mat=bpy.data.materials.new(t['id']+' / '+s['name']);mat.use_nodes=True;n=mat.node_tree.nodes;n.clear();l=mat.node_tree.links;coord=n.new('ShaderNodeTexCoord');coord.location=(-1000,-300)
  art=n.new('ShaderNodeTexImage');art.name='REPLACE_IMAGE';art.label=s['name']+' — load artwork';art.image=image(folder/(s['name']+'-empty.png'));art.extension='EXTEND';art.location=(-1000,200)
  mask=n.new('ShaderNodeTexImage');mask.name='PHYSICAL_MASK — retain';mask.image=image(folder/s['mask'],True);mask.extension='CLIP';mask.location=(-750,-200);l.new(coord.outputs['Window'],mask.inputs['Vector'])
  color=art.outputs['Color']
  if s['lighting']=='relative':
   illumination=n.new('ShaderNodeTexImage');illumination.name='BAKED_RELATIVE_LIGHTING';illumination.image=image(folder/(s['name']+'-illumination.png'),True);illumination.location=(-750,-450);l.new(coord.outputs['Window'],illumination.inputs['Vector']);mul=n.new('ShaderNodeMixRGB');mul.blend_type='MULTIPLY';mul.inputs[0].default_value=1;mul.location=(-400,200);l.new(color,mul.inputs[1]);l.new(illumination.outputs['Color'],mul.inputs[2]);color=mul.outputs[0]
  alpha=n.new('ShaderNodeMath');alpha.operation='MULTIPLY';alpha.location=(-400,-100);l.new(art.outputs['Alpha'],alpha.inputs[0]);l.new(mask.outputs['Color'],alpha.inputs[1]);em=n.new('ShaderNodeEmission');em.location=(-150,200);l.new(color,em.inputs['Color']);tr=n.new('ShaderNodeBsdfTransparent');tr.location=(-150,-100);mix=n.new('ShaderNodeMixShader');mix.location=(100,100);l.new(alpha.outputs[0],mix.inputs[0]);l.new(tr.outputs[0],mix.inputs[1]);l.new(em.outputs[0],mix.inputs[2]);out=n.new('ShaderNodeOutputMaterial');out.location=(350,100);l.new(mix.outputs[0],out.inputs[0])
  ob=mesh(scene,'ASSET — '+s['name'],s['quad'],W,H,z=.01+index*.001,divisions=48,overdraw=.01);ob.data.materials.append(mat);ob['artwork_size']=str(s['artwork_size']);ob['usage']=s['notes'];checks.append((scene,art,folder/(s['name']+'-checker.png')))
notes=bpy.data.texts.new('START HERE');notes.write('Seven fixed-camera photograph templates,22 independent local artwork slots. Choose scene,select ASSET object,replace its image node REPLACE_IMAGE. Empty images are fully transparent. Camera-space physical masks preserve screen rounding,camera islands,fingers and cropped cards. Use full portrait UI without another device frame/camera cutout. Metallic icon prefers a transparent logo. Campaign has8cards,phone and3transparent text fields. Native size varies;680px source is not4K detail. Cameras and photographic lighting are fixed; no recovered3D people/phones. Make a copy. Inspect each branded result independently. See README.md and template.json for all local quads and artwork sizes.')
bpy.context.window.scene=bpy.data.scenes['01-metallic-icon-macro']
for s in initial_scenes:bpy.data.scenes.remove(s)
for ui in bpy.data.screens:
 for area in ui.areas:
  if area.type=='VIEW_3D':area.spaces.active.region_3d.view_perspective='CAMERA';area.spaces.active.shading.type='MATERIAL'
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'mobile-templates.blend'),compress=True)
for scene in bpy.data.scenes:
 scene.render.filepath=str(ROOT/'checks'/(scene.name+'-blank.png'));bpy.ops.render.render(write_still=True,scene=scene.name)
for scene,art,path in checks:art.image=image(path)
for scene in bpy.data.scenes:
 scene.render.filepath=str(ROOT/'checks'/(scene.name+'-placement.png'));bpy.ops.render.render(write_still=True,scene=scene.name)
print('Saved seven EMPTY scenes and rendered seven actual multi-slot checker scenes; diagnostic artwork not saved in master.')
