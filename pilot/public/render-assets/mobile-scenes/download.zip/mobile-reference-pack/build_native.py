"""Seven native reference-preserving blank templates from built-in imagegen donors.
Only declared replaceable application regions change; physical photographs stay intact.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import numpy as np,json,hashlib
ROOT=Path(__file__).resolve().parent

def cc(binary,seed):
 m=Image.fromarray(np.uint8(binary)*255).copy();assert m.getpixel(tuple(seed))==255,('bad seed',seed)
 ImageDraw.floodfill(m,tuple(seed),128);return Image.fromarray(np.uint8(np.array(m)==128)*255)
def filled(m):
 a=np.array(m);inv=Image.fromarray(255-a).copy();ImageDraw.floodfill(inv,(0,0),128);return Image.fromarray(np.uint8((a>0)|(np.array(inv)==255))*255)
def neutral(photo,seed,minimum=130,delta=45,roi=None):
 a=np.array(photo.convert('RGB')).astype(float);ok=(a.min(2)>minimum)&(a.max(2)-a.min(2)<delta)
 if roi:
  region=np.zeros(ok.shape,bool);x1,y1,x2,y2=roi;region[y1:y2,x1:x2]=1;ok&=region
 return cc(ok,seed)
def hull(mask):
 a=np.array(mask)>0;inner=a.copy();inner[1:]&=a[:-1];inner[:-1]&=a[1:];inner[:,1:]&=a[:,:-1];inner[:,:-1]&=a[:,1:]
 yy,xx=np.where(a&~inner);pts=sorted(set(zip(xx.tolist(),yy.tolist())))
 def cross(o,a,b):return(a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
 lo=[];hi=[]
 for p in pts:
  while len(lo)>1 and cross(lo[-2],lo[-1],p)<=0:lo.pop()
  lo.append(p)
 for p in reversed(pts):
  while len(hi)>1 and cross(hi[-2],hi[-1],p)<=0:hi.pop()
  hi.append(p)
 m=Image.new('L',mask.size);ImageDraw.Draw(m).polygon(lo[:-1]+hi[:-1],fill=255);return m
def rounded(size,box,radius=0,ss=4):
 m=Image.new('L',(size[0]*ss,size[1]*ss));d=ImageDraw.Draw(m);b=tuple(round(v*ss) for v in box)
 if radius:d.rounded_rectangle(b,radius=round(radius*ss),fill=255)
 else:d.rectangle(b,fill=255)
 return m.resize(size,Image.Resampling.LANCZOS)
def fit_quad(mask,rough):
 a=np.array(mask)>0;inside=a.copy();inside[1:]&=a[:-1];inside[:-1]&=a[1:];inside[:,1:]&=a[:,:-1];inside[:,:-1]&=a[:,1:]
 yy,xx=np.where(a&~inside);edge=np.column_stack([xx,yy]).astype(float);lines=[];rng=np.random.default_rng(7302026);diag=[]
 for i in range(4):
  p=np.array(rough[i],float);q=np.array(rough[(i+1)%4],float);v=q-p;length=np.linalg.norm(v);v/=length;n=np.array([-v[1],v[0]]);rel=edge-p;t=rel@v/length
  pts=edge[(t>.14)&(t<.86)&(np.abs(rel@n)<50)];assert len(pts)>20,('too few edge points',i,len(pts))
  best=None;score=0
  for _ in range(200):
   p1,p2=pts[rng.choice(len(pts),2,replace=False)];vv=p2-p1;ll=np.linalg.norm(vv)
   if ll<length*.2:continue
   nn=np.array([-vv[1],vv[0]])/ll;dd=-(nn@p1);keep=np.abs(pts@nn+dd)<.75
   if keep.sum()>score:score=keep.sum();best=keep
  assert best is not None
  pp=pts[best];center=pp.mean(0);_,_,V=np.linalg.svd(pp-center,full_matrices=False);nn=V[-1];dd=-(nn@center);lines.append((nn,dd));diag.append({'edge':i,'inliers':len(pp),'rms':float(np.sqrt(np.mean((pp@nn+dd)**2)))})
 out=[]
 for i in range(4):
  n1,d1=lines[(i-1)%4];n2,d2=lines[i];out.append(np.linalg.solve(np.stack([n1,n2]),-np.array([d1,d2])).tolist())
 return out,diag
def polynomial_material(photo,mask):
 a=np.array(photo.convert('RGB'));yy,xx=np.where(np.array(mask)>220);assert len(xx)>100
 step=max(1,len(xx)//16000);xx=xx[::step];yy=yy[::step];x=xx/photo.width;y=yy/photo.height
 A=np.column_stack([np.ones(len(x)),x,y,x*x,x*y,y*y]);coeff=np.linalg.lstsq(A,a[yy,xx],rcond=None)[0]
 gy,gx=np.mgrid[:photo.height,:photo.width];gx=gx/photo.width;gy=gy/photo.height
 result=np.zeros(a.shape,float)
 for i,basis in enumerate([np.ones_like(gx),gx,gy,gx*gx,gx*gy,gy*gy]):result+=basis[:,:,None]*coeff[i]
 med=np.median(a[yy,xx],axis=0);result=np.clip(result,np.maximum(0,med-45),np.minimum(255,med+45))
 return Image.fromarray(np.uint8(np.clip(result,0,255)))
def warp_photo(material,srcquad,dstquad,size,ss=2):
 A=[];b=[]
 for(x,y),(u,v)in zip(np.array(dstquad)*ss,srcquad):
  A.extend([[x,y,1,0,0,0,-u*x,-u*y],[0,0,0,x,y,1,-v*x,-v*y]]);b.extend([u,v])
 coeff=np.linalg.solve(np.array(A),np.array(b));return material.transform((size[0]*ss,size[1]*ss),Image.Transform.PERSPECTIVE,coeff,Image.Resampling.BICUBIC).resize(size,Image.Resampling.LANCZOS)
def island(photo,roi,seed):
 a=np.array(photo.convert('RGB')).astype(float);ok=a.mean(2)<105;region=np.zeros(ok.shape,bool);x1,y1,x2,y2=roi;region[y1:y2,x1:x2]=1
 m=hull(filled(cc(ok&region,seed)));return m.filter(ImageFilter.GaussianBlur(.5))
def boxquad(box):
 x1,y1,x2,y2=box;return [[x1,y1],[x2,y1],[x2,y2],[x1,y2]]
def slot(root,name,mask,quad,art_size=(1170,2532),light='relative',notes=''):
 rel='masks/'+name+'.png';(root/'masks').mkdir(exist_ok=True);mask.save(root/rel)
 return {'name':name,'mask':rel,'quad':quad,'artwork_size':list(art_size),'lighting':light,'notes':notes}
def merge_masks(ms,size):
 a=np.zeros((size[1],size[0]),np.uint8)
 for m in ms:a=np.maximum(a,np.array(m))
 return Image.fromarray(a)
def finalize(record,original,blank,slots,masks,extra=None):
 folder=ROOT/'templates'/record['id'];folder.mkdir(parents=True,exist_ok=True)
 blank.save(folder/'blank.png');union=merge_masks(masks,original.size);union.save(folder/'replacement-union.png')
 footprint=np.array(union.filter(ImageFilter.MaxFilter(5)))>0;diff=np.abs(np.array(blank).astype(int)-np.array(original).astype(int));assert not np.any(diff[~footprint]),record['id']
 meta={'id':record['id'],'title':record['title'],'source_kind':'user_attachment','original_size':list(original.size),'generated_donor_size':list(Image.open(ROOT/'candidates'/(record['id']+'-gen-v1.png')).size),'blank':'templates/'+record['id']+'/blank.png','original':record['reference'],'slots':slots,'replacement_union':'templates/'+record['id']+'/replacement-union.png','max_change_outside_2px_mask_aa':int(diff[~footprint].max()),'sha256':hashlib.sha256((folder/'blank.png').read_bytes()).hexdigest(),'type':'Fixed-camera image-based composition, no recovered subject geometry','method':'Built-in imagegen cleanup donors; native surface masks and exact original photographic content outside declared replacement regions.'}
 if extra:meta.update(extra)
 (folder/'template.json').write_text(json.dumps(meta,indent=2)+'\n');return meta

PHONE_CONFIG={
 '02-dark-ticket-phone':{'seed':(750,850),'island_seed':(388,333),'island_roi':(290,290,484,371),'rough':[(121,357),(638,249),(1117,1101),(570,1248)]},
 '03-calendar-handheld':{'seed':(340,180),'island_seed':(340,96),'island_roi':(298,81,382,114),'rough':[(216,78),(463,78),(463,608),(216,608)]},
 '05-person-forward-phone':{'seed':(475,410),'island_seed':(690,157),'island_roi':(645,113,739,198),'rough':[(592,49),(815,222),(456,680),(242,521)]},
 '06-pov-handheld-phone':{'seed':(600,400),'island_seed':(600,103),'island_roi':(553,87,642,122),'rough':[(478,83),(723,83),(723,602),(478,602)]},
 '07-low-angle-person-phone':{'seed':(470,540),'island_seed':(324,220),'island_roi':(271,179,374,257),'rough':[(172,272),(441,132),(711,666),(440,811)]}
}
def build_phone(record):
 sid=record['id'];cfg=PHONE_CONFIG[sid];original=Image.open(ROOT/record['reference']).convert('RGB');gen=Image.open(ROOT/'candidates'/(sid+'-gen-v1.png')).convert('RGB');folder=ROOT/'templates'/sid;folder.mkdir(parents=True,exist_ok=True)
 raw=neutral(original,cfg['seed']);outer=filled(raw);q,fit=fit_quad(outer,cfg['rough']);physical=island(original,cfg['island_roi'],cfg['island_seed']);physical.save(folder/'physical-island.png')
 mask=Image.fromarray(np.uint8(np.array(outer).astype(float)*(1-np.array(physical)/255))).filter(ImageFilter.GaussianBlur(.55))
 sx=gen.width/original.width;sy=gen.height/original.height;gseed=(round(cfg['seed'][0]*sx),round(cfg['seed'][1]*sy));graw=neutral(gen,gseed);gq,gfit=fit_quad(filled(graw),[(x*sx,y*sy)for x,y in cfg['rough']]);field=polynomial_material(gen,graw);mapped=warp_photo(field,gq,q,original.size);blank=Image.composite(mapped,original,mask)
 slots=[slot(folder,'screen',mask,q,notes='Physical island and foreground finger boundaries retained. Full portrait UI, no duplicate device frame or camera cutout.')]
 return finalize(record,original,blank,slots,[mask],{'screen_edge_fit':fit,'generated_screen_quad':gq,'generated_edge_fit':gfit,'physical_island':'physical-island.png','material_note':'A smooth donor-screen field is fitted from empty neutral display pixels, so donor hardware cannot ghost into the original mask.'})

def build_macro(record):
 sid=record['id'];original=Image.open(ROOT/record['reference']).convert('RGB');gen=Image.open(ROOT/'candidates'/(sid+'-gen-v1.png')).convert('RGB');folder=ROOT/'templates'/sid;folder.mkdir(parents=True,exist_ok=True);slots=[];masks=[];blank=original.copy();sx=gen.width/original.width;sy=gen.height/original.height
 rough=[(545,696),(943,696),(1030,1058),(632,1058)];raw=neutral(original,(780,750),40,35,(530,680,1050,1075));metal=filled(raw);q,fit=fit_quad(metal,rough)
 groi=(round(530*sx),round(680*sy),round(1050*sx),round(1075*sy));graw=neutral(gen,(round(780*sx),round(750*sy)),40,35,groi);gq,gfit=fit_quad(filled(graw),[(x*sx,y*sy)for x,y in rough]);mapped=warp_photo(gen,gq,q,original.size);metal=metal.filter(ImageFilter.GaussianBlur(.25));blank=Image.composite(mapped,blank,metal);masks.append(metal);slots.append(slot(folder,'metallic-logo',metal,q,(1024,1024),'relative','Transparent brand mark recommended; radial brushed silver is the baked substrate. Full opaque art inherits its relative highlights.'))
 a=np.array(original);roi=np.zeros((original.height,original.width),bool);roi[1240:,680:]=1;blue=hull(filled(cc((a[:,:,2]>100)&(a[:,:,2]>a[:,:,0].astype(float)*1.4)&roi,(950,1330))))
 # Preserve the source blue face and soft perimeter. Only the envelope graphic is erased.
 original_blue_samples=Image.fromarray(np.uint8((a[:,:,0]<30)&(a[:,:,2]>200)&roi)*255)
 bluefield=polynomial_material(original,original_blue_samples)
 bluefield.save(folder/'blue-substrate.png')
 bf=np.array(bluefield).astype(float);bluealpha=np.clip(a[:,:,2]/np.maximum(1,bf[:,:,2]),0,1)
 bluealpha[np.array(blue.filter(ImageFilter.MinFilter(9)))>250]=1
 blue=Image.fromarray(np.uint8(bluealpha*np.array(blue.filter(ImageFilter.MaxFilter(7))))).filter(ImageFilter.GaussianBlur(.15))
 envelope=Image.fromarray(np.uint8((a[:,:,0]>65)&(a[:,:,1]>130)&roi&(np.indices(roi.shape)[0]>1365))*255).filter(ImageFilter.MaxFilter(15)).filter(ImageFilter.GaussianBlur(2))
 blank=Image.composite(bluefield,blank,envelope);masks.append(envelope)
 blueq=[[x+178,y+586]for x,y in q];slots.append(slot(folder,'cropped-blue-icon',blue,blueq,(1024,1024),'relative','Full virtual icon extends below canvas. Visible mask is exact; unseen extent is an extrapolated placement guide.'))
 white=filled(neutral(original,(1190,780),180,40,(1125,680,1200,1100))).filter(ImageFilter.GaussianBlur(.25));whiteq=[[x+580,y]for x,y in q];slots.append(slot(folder,'cropped-white-icon',white,whiteq,(1024,1024),'relative','Partly off-canvas virtual icon; original blank white substrate is retained.'))
 # The original surrounding glass is exactly RGB4; match that field rather than donor noise.
 donor=Image.new('RGB',original.size,(4,4,4))
 for name,box,art,quad in [('status-time',(550,315,880,440),(1000,350),[(570,330),(840,330),(862,425),(592,425)]),('app-label',(690,1070,1040,1180),(1600,450),[(710,1080),(1010,1080),(1033,1172),(733,1172)])]:
  m=rounded(original.size,box).filter(ImageFilter.GaussianBlur(4));blank=Image.composite(donor,blank,m);masks.append(m);slots.append(slot(folder,name,m,quad,art,'none','Optional digital text on black glass; source wording is cleared, not hardware.'))
 return finalize(record,original,blank,slots,masks,{'metal_edge_fit':fit,'generated_metal_quad':gq,'generated_edge_fit':gfit,'macro_note':'Silver primary face, partial blue/white tiles, clock/name fields are independent roles. Physical phone rim/button/grain remain original.'})

def build_campaign(record):
 sid=record['id'];original=Image.open(ROOT/record['reference']).convert('RGB');gen=Image.open(ROOT/'candidates'/(sid+'-gen-v1.png')).convert('RGB');folder=ROOT/'templates'/sid;folder.mkdir(parents=True,exist_ok=True);slots=[];masks=[];blank=original.copy();size=original.size
 # Source front view: native active-display bounds, rounded corners and true island.
 box=(387.5,516.5,666.5,1120.5);q=boxquad(box);outer=rounded(size,box,39);physical=rounded(size,(482.5,524.5,571.5,550.5),13);physical.save(folder/'physical-island.png');screen=Image.fromarray(np.uint8(np.array(outer).astype(float)*(1-np.array(physical)/255)))
 sx=gen.width/original.width;sy=gen.height/original.height;graw=neutral(gen,(round(520*sx),round(800*sy)),140,50);gq,gfit=fit_quad(filled(graw),[(x*sx,y*sy)for x,y in q]);field=polynomial_material(gen,graw);mapped=warp_photo(field,gq,q,size);blank=Image.composite(mapped,blank,screen);masks.append(screen);slots.append(slot(folder,'screen',screen,q,notes='Replace wallpaper and UI as one portrait asset; retain real island.'))
 backdrop=Image.new('RGB',size,(245,245,247))
 # Preserve the phone's neutral cast shadow in card gutters while removing colored ringing.
 ring_luma=np.minimum(np.array(original).max(2),245).astype(np.uint8)
 ringfield=Image.fromarray(np.repeat(ring_luma[:,:,None],3,axis=2)).filter(ImageFilter.GaussianBlur(.6))
 for row,(y1,y2)in enumerate([(583.5,777.5),(794.5,988.5)]):
  for col,(x1,x2)in enumerate([(-48.5,147.5),(164.5,359.5),(694.5,889.5),(906.5,1101.5)]):
   b=(x1,y1,x2,y2);clear=rounded(size,(x1-7,y1-7,x2+7,y2+7),12);blank=Image.composite(ringfield,blank,clear);masks.append(clear)
   face=rounded(size,b,6.5);blank=Image.composite(Image.new('RGB',size,(218,218,221)),blank,face);masks.append(face);slots.append(slot(folder,'art-card-%02d'%(row*4+col+1),face,boxquad(b),(1024,1024),'none','Original card crop/position retained. Native source card is square; partly clipped at canvas where applicable.'))
 for name,b,art in [('brand-signature',(400,145,655,230),(1600,500)),('headline',(215,250,840,415),(2200,650)),('footer-copy',(200,1210,855,1365),(2200,500))]:
  # Expanded clear boxes remove complete source typography; art slot stays inside it.
  clearbox=(b[0]-15,b[1]-10,b[2]+15,b[3]+10);clear=rounded(size,clearbox);blank=Image.composite(backdrop,blank,clear);masks.append(clear);slots.append(slot(folder,name,rounded(size,b),boxquad(b),art,'none','Transparent campaign graphic/text slot; create truthful brand copy, do not inherit the original promotion/terms.'))
 return finalize(record,original,blank,slots,masks,{'campaign_note':'8 separate card faces,1 phone screen, independent brand/headline/footer fields; no source offer or music branding retained. Cards are planar campaign graphics, not recovered album objects.','generated_screen_quad':gq,'generated_edge_fit':gfit,'physical_island':'physical-island.png'})

def main():
 records=json.loads((ROOT/'inputs.json').read_text());result=[]
 for r in records:
  print('BUILD',r['id'],flush=True)
  if r['id'].startswith('01-'):m=build_macro(r)
  elif r['id'].startswith('04-'):m=build_campaign(r)
  else:m=build_phone(r)
  result.append(m);(ROOT/'templates-progress.json').write_text(json.dumps(result,indent=2)+'\n')
 manifest={'template_count':7,'source':'Seven user-provided attachments, copied and hashed in inputs.json','mode':'Built-in imagegen donors plus native exact-photograph surface compositing','templates':result,'placement_review_required':'Every blank and every populated test-chart scene must be independently reviewed; future supplied artwork still needs its own finishing check.'}
 (ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('BUILT7 templates;',sum(len(m['slots'])for m in result),'replacement roles')
if __name__=='__main__':main()
