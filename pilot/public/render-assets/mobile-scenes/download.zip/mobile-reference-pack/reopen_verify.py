"""Run with Blender --background mobile-templates.blend --python reopen_verify.py."""
from pathlib import Path
import bpy,json
ROOT=Path(__file__).resolve().parent
assert len(bpy.data.scenes)==7
nodes=[n for m in bpy.data.materials if m.use_nodes for n in m.node_tree.nodes if n.name=='REPLACE_IMAGE']
assert len(nodes)==22
for n in nodes:
 assert 'empty' in n.image.name,n.image.name
 assert n.extension=='EXTEND'
for i in bpy.data.images:
 if i.source=='FILE':assert i.packed_file,i.name
for scene in bpy.data.scenes:
 scene.render.filepath=str(ROOT/'checks'/(scene.name+'-reopened.png'));bpy.ops.render.render(write_still=True,scene=scene.name)
(ROOT/'checks/reopen-structure.json').write_text(json.dumps({'scene_count':7,'artwork_slot_count':22,'default_artwork':'transparent empty images','all_file_images_packed':True},indent=2)+'\n')
