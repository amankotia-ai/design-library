"""Blender --background mobile-templates.blend --python replace_artwork.py -- artwork.json output-directory

artwork.json: {"06-pov-handheld-phone": {"screen": "/absolute/path/ui.png"}}
Only assigned scenes render. Relative art paths resolve beside the JSON file.
"""
from pathlib import Path
import bpy,json,sys
args=sys.argv[sys.argv.index('--')+1:];mapping_path=Path(args[0]).resolve();mapping=json.loads(mapping_path.read_text());out=Path(args[1]).resolve();out.mkdir(parents=True,exist_ok=True)
for scene_name,slots in mapping.items():
 scene=bpy.data.scenes[scene_name]
 for slot,path in slots.items():
  # Blender adds numeric suffixes to repeated object names across different scenes.
  ob=next((obj for obj in scene.objects if obj.type=='MESH' and obj.active_material and obj.active_material.use_nodes and (obj.active_material.node_tree.nodes.get('REPLACE_IMAGE') is not None) and obj.active_material.node_tree.nodes['REPLACE_IMAGE'].label==slot+' — load artwork'),None)
  if not ob:raise ValueError('Unknown artwork slot '+scene_name+'/'+slot)
  source=Path(path).expanduser()
  if not source.is_absolute():source=mapping_path.parent/source
  image=bpy.data.images.load(str(source.resolve()));image.pack();ob.data.materials[0].node_tree.nodes['REPLACE_IMAGE'].image=image
 scene.render.filepath=str(out/(scene_name+'.png'));bpy.ops.render.render(write_still=True,scene=scene_name)
bpy.ops.wm.save_as_mainfile(filepath=str(out/'branded-mobile-scenes.blend'),compress=True)
