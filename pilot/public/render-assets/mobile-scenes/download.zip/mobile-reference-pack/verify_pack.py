"""Verify hash-pinned independent acceptance after extraction; standard library only."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
delivery=json.loads((ROOT/'delivery.json').read_text());assert delivery['status']=='pass'
for record in delivery['accepted_files']:
 path=ROOT/record['file'];assert path.is_file(),path
 assert hashlib.sha256(path.read_bytes()).hexdigest()==record['sha256'],path
print('PASS:',len(delivery['accepted_files']),'independently pinned files match;7 templates,22 placement slots.')
