from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import numpy as np,json
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'manifest.json').read_text())
for t in manifest['templates']:
 folder=ROOT/'templates'/t['id'];blank=np.array(Image.open(ROOT/t['blank']).convert('RGB')).astype(float)
 for s in t['slots']:
  name=s['name'];w,h=s['artwork_size'];Image.new('RGBA',(w,h)).save(folder/(name+'-empty.png'))
  substrate=np.array(Image.open(folder/'blue-substrate.png')).astype(float) if name=='cropped-blue-icon' else blank
  mask=np.array(Image.open(folder/s['mask']))>220;lum=substrate@np.array([.2126,.7152,.0722]);ratio=np.clip(lum/max(1,np.median(lum[mask])),.55,1.15)
  illum=np.uint8(np.clip(ratio*255,0,255));Image.fromarray(illum).save(folder/(name+'-illumination.png'))
  chart=Image.new('RGBA',(w,h));d=ImageDraw.Draw(chart);step=max(1,w//8)
  for y in range(0,h,step):
   for x in range(0,w,step):d.rectangle((x,y,x+step-1,y+step-1),fill=('#208fbd' if (x//step+y//step)%2 else '#faf2cc'))
  thickness=max(5,w//60);d.rectangle((thickness//2,thickness//2,w-1-thickness//2,h-1-thickness//2),outline='#ff3458',width=thickness)
  d.line((w//2,0,w//2,h),fill='#e91a72',width=thickness);d.line((0,h//2,w,h//2),fill='#e91a72',width=thickness)
  try:font=ImageFont.truetype('/System/Library/Fonts/Helvetica.ttc',max(16,w//18))
  except OSError:
   try:font=ImageFont.truetype('DejaVuSans.ttf',max(16,w//18))
   except OSError:font=ImageFont.load_default()
  d.text((w*.05,h*.08),'TOP / '+name,fill='black',font=font);d.text((w*.05,h*.84),'BOTTOM',fill='black',font=font)
  chart.save(folder/(name+'-checker.png'))
print('Prepared',sum(len(t['slots'])for t in manifest['templates']),'independent artwork slots')
