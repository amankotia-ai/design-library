"""Freeze accepted ARCO byte copies and package renders, artwork and source."""
from pathlib import Path
from PIL import Image
import json,hashlib,shutil,zipfile
ROOT=Path(__file__).resolve().parent
spec=[('01-phone','v2'),('02-auditorium','v3'),('03-social-cards','v2'),('04-laptop-sticker','v2')]
qa_files=list((ROOT/'qa').glob('*.json'))
reports=[json.loads(f.read_text()) for f in qa_files]
accepted_text=json.dumps([r for r in reports if r.get('status')=='pass'])
delivery=ROOT/'delivery';delivery.mkdir(exist_ok=True)
rows=[]
for sid,version in spec:
 source=ROOT/'candidates'/(sid+'-exact-'+version+'.png');digest=hashlib.sha256(source.read_bytes()).hexdigest()
 if digest not in accepted_text:raise SystemExit('Independent accepted hash report required for '+source.name)
 target=delivery/(sid+'.png');shutil.copy2(source,target)
 assert hashlib.sha256(target.read_bytes()).hexdigest()==digest
 rows.append({'id':sid,'file':str(target.relative_to(ROOT)),'accepted_candidate':str(source.relative_to(ROOT)),'size':list(Image.open(target).size),'sha256':digest,'qa':'independent pass'})
manifest={'brand':'ARCO — fictional technology workspace concept','tagline':'Good work, together.','scope':'Four requested photographed applications with exact artwork and preserved scene geometry','photographic_detail':'Native1536x1024 phone;1672x941 otherthree; no4K claim','method':'Built-in imagegen first passes, then deterministic source-artwork mapping and physical masks after independent review','files':rows,'assets':'assets/','rebuild':['python create_assets.py','python compose_exact.py'],'qa_reports':'qa/'}
(ROOT/'final-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
target=ROOT/'ARCO-tech-brand.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(ROOT.rglob('*')):
  rel=p.relative_to(ROOT)
  if not p.is_file() or p==target or 'candidates' in rel.parts or '__pycache__' in rel.parts or p.suffix=='.zip' or p.name.startswith('debug-') or p.name in {'progress-preview.jpg','package-delivery-manifest.json'}:continue
  z.write(p,Path('ARCO-tech-brand')/rel)
with zipfile.ZipFile(target) as z:assert z.testzip() is None;count=len(z.namelist())
result={'file':str(target),'bytes':target.stat().st_size,'entries':count,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
(ROOT/'package-delivery-manifest.json').write_text(json.dumps(result,indent=2)+'\n')
print('Packaged4 accepted final renders + brand artwork + editable source:',round(result['bytes']/1024/1024,2),'MiB')
