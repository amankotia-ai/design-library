"""Fit exact ARCO artwork to the authoritative blank plates.
Deterministic homographies with explicit silhouette/island masks and baked illumination.
No physical objects/camera/light geometry is recovered by this fixed-photo composition.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import numpy as np
import json,hashlib
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'candidates';OUT.mkdir(exist_ok=True)
MASKS=ROOT/'masks';MASKS.mkdir(exist_ok=True)
FITS={}
MANIFEST=ROOT/'composition-manifest-v2.json'

def component(im,roi,seed,minimum=130,delta=35):
 a=np.array(im.convert('RGB')).astype(float);ok=(a.min(2)>minimum)&(a.max(2)-a.min(2)<delta)
 region=np.zeros(ok.shape,bool);x1,y1,x2,y2=roi;region[y1:y2,x1:x2]=True;ok&=region
 m=Image.fromarray(np.uint8(ok)*255).copy();assert m.getpixel(seed)==255,('seed outside neutral surface',seed)
 ImageDraw.floodfill(m,seed,128,thresh=0);return Image.fromarray(np.uint8(np.array(m)==128)*255)

def fitted_quad(mask,rough,name):
 a=np.array(mask)>0;inside=a.copy()
 inside[1:,:]&=a[:-1,:];inside[:-1,:]&=a[1:,:];inside[:,1:]&=a[:,:-1];inside[:,:-1]&=a[:,1:]
 yy,xx=np.where(a&~inside);boundary=np.column_stack([xx,yy]).astype(float);lines=[];diagnostics=[]
 rng=np.random.default_rng(22026)
 for i in range(4):
  p=np.array(rough[i],float);q=np.array(rough[(i+1)%4],float);v=q-p;length=np.linalg.norm(v);v/=length;n=np.array([-v[1],v[0]])
  rel=boundary-p;t=rel@v/length;dist=np.abs(rel@n)
  pts=boundary[(t>.14)&(t<.86)&(dist<25)]
  assert len(pts)>25,(name,i,len(pts))
  best=None;score=0
  for _ in range(150):
   u1,u2=pts[rng.choice(len(pts),2,replace=False)];vv=u2-u1;ll=np.linalg.norm(vv)
   if ll<length*.25:continue
   nn=np.array([-vv[1],vv[0]])/ll;dd=-(nn@u1);keep=np.abs(pts@nn+dd)<.72
   if keep.sum()>score:best=keep;score=keep.sum()
  assert best is not None
  ps=pts[best];center=ps.mean(0);_,_,V=np.linalg.svd(ps-center,full_matrices=False);nn=V[-1];dd=-(nn@center)
  lines.append((nn,dd));diagnostics.append({'edge':i,'boundary_points':len(pts),'line_inliers':len(ps),'rms_pixels':float(np.sqrt(np.mean((ps@nn+dd)**2)))})
 quad=[]
 for i in range(4):
  n1,d1=lines[(i-1)%4];n2,d2=lines[i];xy=np.linalg.solve(np.stack([n1,n2]),-np.array([d1,d2]));quad.append(xy.tolist())
 FITS[name]={'quad':quad,'line_fit':diagnostics}
 return quad

def homography(quad,src=((0,0),(1,0),(1,1),(0,1))):
 A=[];b=[]
 for (u,v),(x,y) in zip(src,quad):
  A.extend([[u,v,1,0,0,0,-x*u,-x*v],[0,0,0,u,v,1,-y*u,-y*v]]);b.extend([x,y])
 return np.append(np.linalg.solve(np.array(A,float),np.array(b,float)),1).reshape(3,3)

def inset_quad(quad,u=.018,v=.032):
 H=homography(quad);out=[]
 for pt in [(u,v),(1-u,v),(1-u,1-v),(u,1-v)]:
  q=H@np.array([*pt,1]);out.append((q[:2]/q[2]).tolist())
 return out

def warp(art,quad,size,ss=3,edge_clamp=False):
 w,h=art.size;dest=np.array(quad,float)*ss;src=np.array([(0,0),(w,0),(w,h),(0,h)],float);A=[];b=[]
 art=art.convert('RGBA')
 if edge_clamp:
  pad=16;art=Image.fromarray(np.pad(np.array(art),((pad,pad),(pad,pad),(0,0)),mode='edge'));src+=pad
 for (x,y),(u,v) in zip(dest,src):
  A.extend([[x,y,1,0,0,0,-u*x,-u*y],[0,0,0,x,y,1,-v*x,-v*y]]);b.extend([u,v])
 c=np.linalg.solve(np.array(A),np.array(b))
 return art.convert('RGBA').transform((size[0]*ss,size[1]*ss),Image.Transform.PERSPECTIVE,c,Image.Resampling.BICUBIC).resize(size,Image.Resampling.LANCZOS)

def polygon_mask(size,quad,ss=4):
 m=Image.new('L',(size[0]*ss,size[1]*ss));ImageDraw.Draw(m).polygon([(round(x*ss),round(y*ss)) for x,y in quad],fill=255)
 return m.resize(size,Image.Resampling.LANCZOS)

def apply(photo,art,quad,mask,shade='paper',edge_clamp=False):
 layer=warp(art,quad,photo.size,edge_clamp=edge_clamp);a=np.array(layer).astype(float);base=np.array(photo.convert('RGB')).astype(float)
 if shade=='screen':factor=np.clip(base.mean(2)/245,.86,1.02)[:,:,None]
 else:factor=np.clip(base/245,.60,1.04)
 a[:,:,:3]*=factor;a[:,:,3]*=np.array(mask)/255.
 a=np.clip(a,0,255).astype('uint8');return Image.alpha_composite(photo.convert('RGBA'),Image.fromarray(a)).convert('RGB')

def main():
 records=[]
 # Native screen shape excludes rounded corners and the real hardware island.
 photo=Image.open(ROOT/'inputs/vadim-phone-desk.png').convert('RGB')
 m=component(photo,(405,235,1115,790),(750,500),130,35)
 q=fitted_quad(m,[(422,405),(623,247),(1090,592),(927,766)],'phone-screen')
 m=m.filter(ImageFilter.GaussianBlur(.30));m.save(MASKS/'phone-screen-with-island.png')
 result=apply(photo,Image.open(ROOT/'assets/phone-ui.png'),q,m,'screen');path=OUT/'01-phone-exact-v2.png';result.save(path);records.append(('01-phone',path,m))
 # Exact framed panel, with native frame and contact shadow kept from the plate.
 photo=Image.open(ROOT/'inputs/vadim-auditorium-display.png').convert('RGB')
 m=component(photo,(390,265,1280,665),(800,450),150,45)
 q=fitted_quad(m,[(410,279),(1264,279),(1264,650),(410,650)],'auditorium-panel')
 m=m.filter(ImageFilter.GaussianBlur(.22));m.save(MASKS/'auditorium-panel.png')
 result=apply(photo,Image.open(ROOT/'assets/auditorium-campaign.png'),q,m,edge_clamp=True);path=OUT/'02-auditorium-exact-v3.png';result.save(path);records.append(('02-auditorium',path,m))
 # Five independent exact poster applications, one-pixel paper margin retained.
 photo=Image.open(ROOT/'inputs/vadim-five-social-cards.png').convert('RGB');combined=Image.new('L',photo.size)
 social_quads=[]
 for i,(x1,x2) in enumerate([(182,432),(447,696),(711,960),(975,1224),(1239,1489)],1):
  box=(x1+1,277,x2,663);q=[(box[0],box[1]),(box[2],box[1]),(box[2],box[3]),(box[0],box[3])]
  ss=4;mm=Image.new('L',(photo.width*ss,photo.height*ss));ImageDraw.Draw(mm).rounded_rectangle(tuple(round(v*ss) for v in box),radius=10*ss,fill=255);mm=mm.resize(photo.size,Image.Resampling.LANCZOS)
  photo=apply(photo,Image.open(ROOT/'assets'/('social-%02d.png'%i)),q,mm);mm.save(MASKS/('social-card-%02d.png'%i));combined=Image.fromarray(np.maximum(np.array(combined),np.array(mm)));social_quads.append(q)
 FITS['social-cards']={'quads':social_quads,'mask':'inset one-pixel paper frame and rounded corners; all original gutters remain'}
 combined.save(MASKS/'social-cards-combined.png');path=OUT/'03-social-cards-exact-v2.png';photo.save(path);records.append(('03-social-cards',path,combined))
 # Real sticker rectangle with a clear original paper border and baked shading.
 photo=Image.open(ROOT/'inputs/vadim-laptop-sticker.png').convert('RGB')
 surface=component(photo,(661,306,964,519),(802,408),160,44)
 q=fitted_quad(surface,[(750,328),(933,423),(864,495),(683,399)],'sticker-paper')
 q=inset_quad(q,.018,.032);FITS['sticker-ink']={'quad':q,'paper_border':'preserved by physical inset'}
 m=polygon_mask(photo.size,q);m.save(MASKS/'sticker-ink.png')
 result=apply(photo,Image.open(ROOT/'assets/laptop-sticker.png'),q,m);path=OUT/'04-laptop-sticker-exact-v2.png';result.save(path);records.append(('04-laptop-sticker',path,m))
 manifest={'renderer':'Exact source artwork with deterministic homographies, rounded/island masks and source photographic illumination after imagegen first-pass audit','type':'Fixed-camera image composition, no recovered subject geometry','fits':FITS,'files':[]}
 for sid,path,mask in records:
  im=Image.open(path);record_path=str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path);manifest['files'].append({'id':sid,'file':record_path,'size':list(im.size),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 MANIFEST.write_text(json.dumps(manifest,indent=2)+'\n')
 print('Composed all four exact-artwork native candidates, preserving original photographic geometry.')

if __name__=='__main__':main()
