"""ARCO fictional technology identity and editable deterministic campaign assets.
Uses local Avenir Next fonts; no fonts are redistributed. All product UI is concept/demo.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import json,math

ROOT=Path(__file__).resolve().parent
ASSETS=ROOT/'assets';ASSETS.mkdir(parents=True,exist_ok=True)
BLUE='#2159F4';IVORY='#F3F0E9';INK='#10232D';LIME='#C8EB73';SLATE='#72838A';LINE='#DCE1DE';WHITE='#FFFFFF'
FONT='/System/Library/Fonts/Avenir Next.ttc'
def font(size,weight='regular'):return ImageFont.truetype(FONT,round(size),index={'bold':0,'demi':2,'medium':5,'regular':7}[weight])
def text(im,x,y,value,size,color=INK,weight='regular',anchor='lt'):
 ImageDraw.Draw(im).text((round(x),round(y)),value,font=font(size,weight),fill=color,anchor=anchor,stroke_width=0)
def lines(im,x,y,values,size,color=INK,weight='demi',leading=1.18):
 for i,value in enumerate(values):text(im,x,y+i*size*leading,value,size,color,weight)
def rule(im,box,color=LINE,width=2):ImageDraw.Draw(im).line(box,fill=color,width=width)

def mark(im,x,y,size,color=BLUE):
 d=ImageDraw.Draw(im);s=size/128;sw=16*s
 for left,top,right,cy,bottom in [(16,16,112,64,112)]:
  l=x+left*s;r=x+right*s;c=y+cy*s;t=y+top*s;b=y+bottom*s
  d.arc((l,t,r,t+2*(c-t)),180,360,fill=color,width=round(sw))
  # Arc is stroked inward in Pillow; use its visible leg-center for vertical continuation.
  lx=l+sw/2;rx=r-sw/2
  d.line((lx,c,lx,b),fill=color,width=round(sw));d.line((rx,c,rx,b),fill=color,width=round(sw))
  rad=sw/2
  for xx in [lx,rx]:d.ellipse((xx-rad,b-rad,xx+rad,b+rad),fill=color)
 d.rounded_rectangle((x+52*s,y+60*s,x+76*s,y+120*s),radius=12*s,fill=color)

def signature(im,x,y,height,color=BLUE):
 mark(im,x,y,height,color)
 f=font(height*.86,'bold');bounds=f.getbbox('arco',anchor='lt');glyph_height=bounds[3]-bounds[1]
 text(im,x+height*1.15,y+height*.53125-glyph_height/2,'arco',height*.86,color,'bold')
def save(im,name):im.save(ASSETS/name)

def bridge_pattern(im,x,y,w,h,color,stroke=15):
 d=ImageDraw.Draw(im)
 for i in range(5):
  xx=x+i*stroke*2.1;yy=y+i*stroke*2.1;ww=w-i*stroke*4.2
  if ww<40:break
  d.arc((xx,yy,xx+ww,yy+ww),180,360,fill=color,width=stroke)
  cy=yy+ww/2
  if cy<h+y:
   d.line((xx+stroke/2,cy,xx+stroke/2,y+h),fill=color,width=stroke)
   d.line((xx+ww-stroke/2,cy,xx+ww-stroke/2,y+h),fill=color,width=stroke)

def phone_ui():
 im=Image.new('RGB',(1170,2532),IVORY);d=ImageDraw.Draw(im)
 # Safe status region leaves room for the photographed physical island.
 text(im,88,58,'9:41',37,INK,'demi');d.rounded_rectangle((984,70,1051,101),radius=7,outline=INK,width=3);d.rectangle((990,76,1038,95),fill=INK);d.rectangle((1054,80,1060,91),fill=INK)
 signature(im,70,207,110,BLUE);d.ellipse((997,219,1097,319),fill=INK);text(im,1047,268,'A',39,IVORY,'demi','mm')
 text(im,78,407,'YOUR WORKSPACE',26,SLATE,'demi')
 lines(im,70,478,['Today,','in focus.'],115,INK,'medium',1.12)
 text(im,78,770,'A little clarity for the work ahead.',33,SLATE)
 d.rounded_rectangle((70,882,1100,1407),radius=42,fill=BLUE)
 text(im,124,941,'PROJECT / 01',27,IVORY,'demi');text(im,124,1025,'Website launch',61,WHITE,'demi')
 text(im,124,1130,'The next chapter, taking shape.',33,'#D6E0FF')
 for i in range(3):
  x=124+i*59;d.ellipse((x,1260,x+74,1334),fill=[LIME,IVORY,'#97B7FF'][i],outline=BLUE,width=6)
  text(im,x+37,1297,['M','J','A'][i],26,INK,'demi','mm')
 d.rounded_rectangle((818,1270,1038,1333),radius=30,fill=LIME);text(im,928,1302,'In progress',24,INK,'demi','mm')
 text(im,78,1510,'Up next',46,INK,'demi');text(im,1069,1525,'View all',27,BLUE,'medium','rt')
 tasks=[('Review landing page','Design / Website launch'),('Share the product brief','Docs / Team workspace'),('Choose the next step','Decisions / Planning')]
 for i,(title,meta) in enumerate(tasks):
  y=1625+i*170;d.rounded_rectangle((82,y+7,126,y+51),radius=12,outline='#A8B2B4',width=3)
  text(im,160,y,title,38,INK,'medium');text(im,160,y+65,meta,25,SLATE)
  if i<2:rule(im,(160,y+130,1085,y+130),LINE,2)
 rule(im,(70,2208,1100,2208),LINE,2)
 for i,(label,col) in enumerate([('Home',BLUE),('Projects',SLATE),('Inbox',SLATE)]):
  x=[213,585,956][i]
  if i==0:
   d.line((x-28,2300,x,2275,x+28,2300),fill=col,width=6);d.rectangle((x-20,2300,x+20,2328),outline=col,width=5)
  elif i==1:d.rounded_rectangle((x-28,2279,x+28,2329),radius=7,outline=col,width=5)
  else:d.rounded_rectangle((x-30,2283,x+30,2325),radius=8,outline=col,width=5);d.line((x-28,2286,x,2307,x+28,2286),fill=col,width=4)
  text(im,x,2360,label,26,col,'medium','mt')
 d.rounded_rectangle((430,2485,740,2498),radius=7,fill=INK)
 return im

def campaign():
 im=Image.new('RGB',(2400,1040),BLUE);d=ImageDraw.Draw(im)
 signature(im,112,84,100,IVORY)
 lines(im,115,285,['Good work,','together.'],166,IVORY,'medium',1.1)
 text(im,122,841,'A shared workspace for product teams.',41,IVORY)
 text(im,124,943,'PROJECTS  /  DOCS  /  DECISIONS',24,'#BCCCFF','demi')
 # Oversized architectural mark has a deliberate graphic crop at bottom.
 bridge_pattern(im,1580,245,650,860,LIME,28)
 d.ellipse((2113,122,2201,210),fill=IVORY)
 return im

def social_cards():
 W,H=1080,1672;out=[]
 # 1 / campaign anchor
 im=Image.new('RGB',(W,H),BLUE);signature(im,62,64,95,IVORY)
 lines(im,70,316,['Good work,','together.'],117,IVORY,'medium',1.13)
 bridge_pattern(im,115,806,850,860,LIME,26)
 text(im,74,687,'THE SHARED WORKSPACE',21,IVORY,'demi');out.append(im)
 # 2 / actual product concept, generous type + task components.
 im=Image.new('RGB',(W,H),IVORY);d=ImageDraw.Draw(im);signature(im,62,64,95,BLUE)
 lines(im,70,315,['One space.','Clear focus.'],108,INK,'medium',1.15)
 d.rounded_rectangle((70,717,1010,1340),radius=30,fill=WHITE)
 text(im,111,771,'Website launch',45,INK,'demi');text(im,113,856,'THE NEXT STEP',20,SLATE,'demi')
 for j,(title,status) in enumerate([('Make the brief','Done'),('Shape the page','In progress'),('Share the work','Next')]):
  y=945+j*113;d.ellipse((115,y+2,141,y+28),fill=[LIME,BLUE,'#D5DDDA'][j]);text(im,162,y,title,32,INK,'medium');text(im,960,y+8,status,21,SLATE,'regular','rt')
  if j<2:rule(im,(114,y+76,970,y+76),LINE,2)
 text(im,73,1512,'Projects. Docs. Decisions.',30,INK,'medium');text(im,73,1562,'A SINGLE PLACE TO MOVE FORWARD.',20,SLATE,'demi');out.append(im)
 # 3 / sequence of ideas into action.
 im=Image.new('RGB',(W,H),INK);d=ImageDraw.Draw(im);signature(im,62,64,95,IVORY)
 lines(im,70,315,['From idea','to next.'],115,IVORY,'medium',1.13)
 for j,(label,bg,fg) in enumerate([('01   Think',IVORY,INK),('02   Shape',LIME,INK),('03   Share',BLUE,IVORY)]):
  y=821+j*181;x=70+j*72;d.rounded_rectangle((x,y,929+j*42,y+134),radius=23,fill=bg);text(im,x+40,y+44,label,43,fg,'medium')
 text(im,72,1555,'KEEP THE WORK MOVING.',23,IVORY,'demi');out.append(im)
 # 4 / expressive shared brand geometry.
 im=Image.new('RGB',(W,H),LIME);d=ImageDraw.Draw(im);signature(im,62,64,95,INK)
 lines(im,70,315,['Less noise.','More flow.'],108,INK,'medium',1.15)
 bridge_pattern(im,120,820,840,680,INK,16)
 text(im,72,1555,'A LITTLE CLARITY GOES A LONG WAY.',21,INK,'demi');out.append(im)
 # 5 / closing identity; compact CTA stays a design concept.
 im=Image.new('RGB',(W,H),IVORY);d=ImageDraw.Draw(im);signature(im,62,64,95,BLUE)
 lines(im,70,315,['Make room','for better','work.'],115,INK,'medium',1.13)
 mark(im,290,864,500,BLUE)
 text(im,74,1506,'Good work, together.',36,INK,'medium');text(im,74,1570,'ARCO / PRODUCT CONCEPT',21,SLATE,'demi');out.append(im)
 return out

def identity_board():
 im=Image.new('RGB',(1800,1120),IVORY);d=ImageDraw.Draw(im)
 signature(im,91,84,276,BLUE)
 lines(im,100,485,['Good work,','together.'],98,INK,'medium',1.12)
 text(im,102,781,'A shared workspace for product teams.',34,INK)
 text(im,103,854,'Projects, docs and decisions in one calm place.',25,SLATE)
 d.rounded_rectangle((1120,60,1740,780),radius=28,fill=BLUE);bridge_pattern(im,1190,172,480,608,LIME,20)
 text(im,1149,839,'ARCO / FICTIONAL TECHNOLOGY BRAND',18,SLATE,'demi')
 for i,col in enumerate([BLUE,IVORY,INK,LIME]):
  x=1120+i*155;d.rounded_rectangle((x,901,x+135,1002),radius=11,fill=col,outline='#D9D8D1',width=1);text(im,x,1027,col.upper(),19,INK)
 text(im,102,1040,'IDENTITY + PRODUCT CONCEPT / 2026',19,SLATE,'demi')
 return im

def main():
 # Mark SVG is portable editable vector artwork. PNGs carry the exact design used in renders.
 svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128"><path d="M24 112V64A40 40 0 0 1 104 64V112" fill="none" stroke="'+BLUE+'" stroke-width="16" stroke-linecap="round"/><rect x="52" y="60" width="24" height="60" rx="12" fill="'+BLUE+'"/></svg>'
 (ASSETS/'arco-mark.svg').write_text(svg)
 icon=Image.new('RGBA',(1024,1024),(0,0,0,0));mark(icon,0,0,1024,BLUE);save(icon,'arco-mark.png')
 sig=Image.new('RGBA',(1800,500),(0,0,0,0));signature(sig,20,30,420,BLUE);save(sig,'arco-signature.png')
 save(phone_ui(),'phone-ui.png');save(campaign(),'auditorium-campaign.png')
 for i,im in enumerate(social_cards(),1):save(im,'social-%02d.png'%i)
 sticker=Image.new('RGB',(1600,700),BLUE);signature(sticker,90,110,460,IVORY);save(sticker,'laptop-sticker.png')
 save(identity_board(),'brand-board.png')
 spec={'name':'ARCO','status':'Fictional technology brand and product concept, created for these mockups; no real company/account/launch claims','purpose':'A shared workspace for product teams: projects, docs and decisions','tagline':'Good work, together.','colors':{'cobalt':BLUE,'ivory':IVORY,'ink':INK,'lime':LIME,'slate':SLATE},'typeface':'Avenir Next: Medium, Demi Bold, Bold','font_source':FONT,'font_distribution':'Not bundled','mark':'Nested arches / shared architectural space','copy':{'auditorium':['Good work,','together.','A shared workspace for product teams.','PROJECTS  /  DOCS  /  DECISIONS'],'social_headlines':['Good work, together.','One space. Clear focus.','From idea to next.','Less noise. More flow.','Make room for better work.']},'required_application_assets':{'phone':'phone-ui.png','auditorium':'auditorium-campaign.png','social_cards':['social-%02d.png'%i for i in range(1,6)],'laptop_sticker':'laptop-sticker.png'}}
 (ASSETS/'brand.json').write_text(json.dumps(spec,indent=2)+'\n')
 print('Created ARCO identity, concept phone UI, auditorium campaign, five social cards and sticker art.')

if __name__=='__main__':main()
