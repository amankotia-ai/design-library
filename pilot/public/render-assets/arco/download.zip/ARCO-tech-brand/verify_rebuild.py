"""Reopen saved composition source in a fresh process and compare decoded pixels."""
from pathlib import Path
from PIL import Image,ImageChops
import tempfile,subprocess,sys,json,hashlib
ROOT=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='arco-replay-') as temporary:
 dest=Path(temporary)
 code='import sys;from pathlib import Path;sys.path.insert(0,sys.argv[1]);import compose_exact as c;c.OUT=Path(sys.argv[2]);c.MASKS=c.OUT/"masks";c.MASKS.mkdir();c.MANIFEST=c.OUT/"manifest.json";c.main()'
 subprocess.run([sys.executable,'-c',code,str(ROOT),str(dest)],check=True,capture_output=True,text=True)
 rows=[]
 for p in sorted(dest.glob('*-exact-*.png')):
  original=ROOT/'candidates'/p.name
  if not original.exists():continue
  a=Image.open(original).convert('RGB');b=Image.open(p).convert('RGB');assert a.size==b.size
  diff=ImageChops.difference(a,b);maximum=max(v for ext in diff.getextrema() for v in ext);assert maximum==0,(p.name,maximum)
  rows.append({'file':str(original.relative_to(ROOT)),'size':list(a.size),'max_decoded_pixel_difference':maximum,'sha256':hashlib.sha256(original.read_bytes()).hexdigest()})
 assert len(rows)==4
 report={'status':'pass','method':'Fresh Python subprocess reopens saved source and input assets; all four independently rerendered candidates decode pixel-identically','source_script_sha256':hashlib.sha256((ROOT/'compose_exact.py').read_bytes()).hexdigest(),'files':rows}
 (ROOT/'saved-source-verification.json').write_text(json.dumps(report,indent=2)+'\n')
 print('Saved composition source reproduces all four candidate images exactly.')
