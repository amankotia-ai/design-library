"""Fixed-camera image plates with perspective artwork guides, not recovered 3D.
Run Blender --background --python build_blender.py. Camera and lighting are baked.
"""
import bpy,json
import numpy as np
from pathlib import Path
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'manifest.json').read_text())
slots=json.loads((ROOT/'slots.json').read_text())['scenes']
for o in list(bpy.data.objects):bpy.data.objects.remove(o,do_unlink=True)
for s in list(bpy.data.scenes)[1:]:bpy.data.scenes.remove(s)
first=bpy.data.scenes[0]

def material(name,img,alpha=False):
 m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes;n.clear();l=m.node_tree.links
 t=n.new('ShaderNodeTexImage');t.image=img;t.name='REPLACE_IMAGE' if alpha else 'PACKED_PLATE';t.interpolation='Linear' if alpha else 'Closest'
 e=n.new('ShaderNodeEmission');l.new(t.outputs['Color'],e.inputs['Color']);out=n.new('ShaderNodeOutputMaterial')
 if alpha:
  tr=n.new('ShaderNodeBsdfTransparent');mix=n.new('ShaderNodeMixShader');l.new(t.outputs['Alpha'],mix.inputs[0]);l.new(tr.outputs[0],mix.inputs[1]);l.new(e.outputs[0],mix.inputs[2]);l.new(mix.outputs[0],out.inputs[0])
 else:l.new(e.outputs[0],out.inputs[0])
 return m

def projective_guide(scene,name,corners,mat,z=0,divisions=24):
 # Solve a true projective mapping of a local rectangle into the camera image.
 # Subdivision avoids the two-triangle affine interpolation seam of a lone quad.
 A=[];b=[]
 for (u,v),(x,y) in zip([(0,0),(1,0),(1,1),(0,1)],corners):
  A.extend([[u,v,1,0,0,0,-u*x,-v*x],[0,0,0,u,v,1,-u*y,-v*y]]);b.extend([x,y])
 h=np.append(np.linalg.solve(np.array(A),np.array(b)),1).reshape(3,3)
 verts=[];uvs=[]
 for row in range(divisions+1):
  for col in range(divisions+1):
   u=col/divisions;v=row/divisions;q=h@np.array([u,v,1]);x,y=q[:2]/q[2]
   verts.append(((x/1672-.5)*10,(.5-y/941)*10*941/1672,z));uvs.append((u,1-v))
 faces=[]
 for row in range(divisions):
  for col in range(divisions):
   i=row*(divisions+1)+col;faces.append((i,i+1,i+divisions+2,i+divisions+1))
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update();uv=mesh.uv_layers.new(name='Projective artwork UV')
 for poly in mesh.polygons:
  for li in poly.loop_indices:uv.data[li].uv=uvs[mesh.loops[li].vertex_index]
 obj=bpy.data.objects.new(name,mesh);scene.collection.objects.link(obj);obj.data.materials.append(mat);return obj

for i,r in enumerate(manifest['plates']):
 sid=r['id'];s=first if i==0 else bpy.data.scenes.new(sid);s.name=sid;bpy.context.window.scene=s
 s['type']='Fixed-camera generated photographic plate; local projective safe-area guides; no recovered subject geometry'
 s.render.engine='CYCLES';s.cycles.samples=16;s.cycles.use_denoising=False;s.cycles.pixel_filter_type='BOX'
 s.render.resolution_x=1672;s.render.resolution_y=941;s.render.resolution_percentage=100;s.render.image_settings.file_format='PNG';s.render.filepath='//renders/'+sid+'.png'
 s.view_settings.view_transform='Standard';s.view_settings.look='None'
 camera=bpy.data.cameras.new('Fixed camera');camera.type='ORTHO';camera.ortho_scale=10;camera.sensor_fit='HORIZONTAL'
 cam=bpy.data.objects.new('CAMERA — keep fixed',camera);s.collection.objects.link(cam);cam.location=(0,0,10);s.camera=cam
 image=bpy.data.images.load(str(ROOT/r['plate']));image.pack()
 bg=projective_guide(s,'PLATE — baked photograph',[(0,0),(1672,0),(1672,941),(0,941)],material(sid+' plate',image),z=-.05,divisions=1);bg.hide_select=True
 for j,slot in enumerate(slots[sid]):
  art=bpy.data.images.new(sid+' '+slot['name'],width=slot['artwork_size'][0],height=slot['artwork_size'][1],alpha=True);art.generated_color=(1,1,1,0)
  ob=projective_guide(s,'ASSET — '+slot['name'],slot['corners'],material(sid+' '+slot['name'],art,True),z=.001*j)
  ob['usage']=slot['notes'];ob['surface_lighting']='Guide material displays art as emission. For physical ink apply paper/cloth light and texture; this is not a finished shaded material.'
note=bpy.data.texts.new('START HERE');note.write('Five native1672x941 generated photographic plates, eleven transparent local projective SAFE-AREA guides. Real images packed, blank placeholders generated inside file. Replace REPLACE_IMAGE on ASSET objects. These are fixed cameras with baked scene lighting; no recovered objects or new viewpoints. Guides are conservatively inset. Full bleed needs measured surface masks and independent QA; tote requires cloth warp/shading, rear card needs foreground occlusion, glass needs translucency/reflection preservation. Guide emission is for alignment only, not finished physical print shading. See composition-notes.md, slots.json and visual-qa.md. Save a copy before editing.')
bpy.context.window.scene=first
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'oak-retail-plates.blend'))
print('BUILT',len(manifest['plates']),'scenes;',sum(len(v) for v in slots.values()),'projective safe-area guides')
