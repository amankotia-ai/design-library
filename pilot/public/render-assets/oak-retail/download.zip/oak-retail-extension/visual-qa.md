# Independent finishing review

The user requires a separate reviewer for every final render. Delegate finishing review to an independent agent, including batches and aspect-ratio variants. Production delegation remains optional. A reviewer must inspect the actual final images; a successful render command or contact sheet alone cannot earn a pass. If independent agents are unavailable, complete a self-review and explicitly report that independent review remains unavailable.

Supply the original reference, chosen blank plate, exact brand artwork/copy, output contract, final candidate and relevant masks/UV or composition metadata. `scripts/prepare_qa.py` copies these inputs and records their hashes. Use a separate packet per final candidate. The helper prepares evidence; it never awards a pass.

Inspect the whole image at intended delivery size and critical surfaces at 100% pixels. Inspect every visible repeated object, especially both sides and the lower boundary of a cup wrap, overlap boundaries, fingers, bezels and print seams. Generate close crops or silhouette/wireframe comparisons when they help locate defects. Do not infer that repeated objects share a correct fit.

Check:

- **Alignment and surface fit:** optical centering, intended margins, local object axes, perspective, taper, wrap continuity, seams and silhouettes. Print must reach its intended boundary without spilling past the object. Respect physical occlusion. Preserve the logo's shape while projecting it onto the surface.
- **Texture and material:** adequate source resolution, no stretched/smeared type, unintended moiré, broken hairlines, repeating fragments, alpha halos or over-sharp pasted edges. Keep substrate texture and material response plausible.
- **Lighting:** consistent light direction, surface shading, highlights, reflections, contact shadows and edge shading. Printed ink inherits substrate lighting. Emission is appropriate for an actual display; a photographic plate composite may use baked illumination, which must be described accurately.
- **Asset fidelity and finish:** compare exact words, marks, colors and variant identities with supplied artwork. Watch omitted small copy, distorted glyphs, invented symbols, clipping, floating edges, white gaps, pointed slivers and incorrect mask order. Check crop, visual balance, export dimensions and smallest intended viewing size.

Write `qa-report.json` with reviewer identity, status (`pass`, `needs_fixes`, or `blocked`), final path and SHA-256, evidence paths, dimensions, concrete issues with native-pixel coordinates, severity and suggested correction. A passed report has no unresolved material defects. A minor intentional compromise must be described rather than hidden by an aggregate score.

Send actionable findings back to the maker, correct the source geometry/material/artwork/mask or composition, re-render and review the new hash. Acceptance of an earlier file does not cover a changed final. Continue targeted reversible fixes while meaningful progress is possible; if source resolution, unavailable geometry or tooling prevents completion, deliver a clearly labeled draft with the remaining defect and cause. Do not silently promote a draft to final.

When an editable source is promised, reopen the saved scene/composition with its delivered portable assets and re-render a representative final. Compare decoded pixels separately from file-byte hashes because PNG metadata can differ. Record any sampling/color differences honestly; a matching exported PNG alone does not prove the saved source can reproduce it.

Regression case: the original DAYBREAK/FIELD cup examples used one approximate frustum for three photographed cups. This left white edge strips high on the cups and print overshoot lower down; DAYBREAK's decorative ellipses also extended below the intended artwork boundary. The correction needs both individually fitted physical silhouettes/masks and corrected source artwork. Checking only central logo alignment or unchanged background pixels misses these defects.
