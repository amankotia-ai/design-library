"""Create fixed-camera Blender scenes for the thirty generated plates.
This is an image-plate library, not a reconstruction of the photographed geometry.
Run inside Blender from a fresh startup file.
"""
import bpy,json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'manifest.json').read_text())
for obj in list(bpy.data.objects):bpy.data.objects.remove(obj,do_unlink=True)
for scene in list(bpy.data.scenes)[1:]:bpy.data.scenes.remove(scene)
first=bpy.data.scenes[0]

def image_material(name,img,transparent=False):
    mat=bpy.data.materials.new(name);mat.use_nodes=True
    nodes=mat.node_tree.nodes;nodes.clear();links=mat.node_tree.links
    tex=nodes.new('ShaderNodeTexImage');tex.image=img;tex.location=(-500,100)
    if not transparent:tex.interpolation='Closest'
    tex.name='REPLACE_IMAGE' if transparent else 'PACKED_BLANK_PLATE'
    tex.label='Open your FULL-CANVAS transparent artwork here' if transparent else 'Generated image plate'
    em=nodes.new('ShaderNodeEmission');em.location=(-150,100)
    links.new(tex.outputs['Color'],em.inputs['Color'])
    out=nodes.new('ShaderNodeOutputMaterial');out.location=(300,100)
    if transparent:
        tr=nodes.new('ShaderNodeBsdfTransparent');tr.location=(-150,-50)
        mix=nodes.new('ShaderNodeMixShader');mix.location=(100,100)
        links.new(tex.outputs['Alpha'],mix.inputs[0]);links.new(tr.outputs[0],mix.inputs[1]);links.new(em.outputs[0],mix.inputs[2]);links.new(mix.outputs[0],out.inputs['Surface'])
    else:links.new(em.outputs[0],out.inputs['Surface'])
    return mat

def plane(name,width,height,z,mat,col):
    mesh=bpy.data.meshes.new(name+' mesh')
    mesh.from_pydata([(-width/2,-height/2,z),(width/2,-height/2,z),(width/2,height/2,z),(-width/2,height/2,z)],[],[(0,1,2,3)])
    mesh.update();uv=mesh.uv_layers.new(name='Canvas UV')
    for loop,co in zip(uv.data,[(0,0),(1,0),(1,1),(0,1)]):loop.uv=co
    obj=bpy.data.objects.new(name,mesh);col.objects.link(obj);obj.data.materials.append(mat)
    return obj

for i,item in enumerate(manifest['plates']):
    sid=item['id'];scene=first if i==0 else bpy.data.scenes.new(sid);scene.name=sid;bpy.context.window.scene=scene
    scene['type']='Fixed-camera image plate with optional full-canvas artwork overlay; no subject geometry'
    scene['source_url']=item['source_url'];scene['usage']='Keep camera fixed. Full-canvas overlay uses same dimensions as the plate. Add local decal meshes manually when needed.'
    scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False;scene.cycles.pixel_filter_type='BOX'
    w,h=item['generated_dimensions'];scene.render.resolution_x=w;scene.render.resolution_y=h;scene.render.resolution_percentage=100
    scene.render.image_settings.file_format='PNG';scene.render.filepath='//renders/'+sid+'.png'
    scene.view_settings.view_transform='Standard';scene.view_settings.look='None'
    col=bpy.data.collections.new('PLATE — locked camera');scene.collection.children.link(col)
    art=bpy.data.collections.new('ARTWORK — full canvas or add your own surfaces');scene.collection.children.link(art)
    camera=bpy.data.cameras.new(sid+' camera');camera.type='ORTHO';camera.ortho_scale=10;camera.sensor_fit='HORIZONTAL'
    cam=bpy.data.objects.new('CAMERA — keep fixed',camera);col.objects.link(cam);cam.location=(0,0,10);scene.camera=cam
    img=bpy.data.images.load(str(ROOT/item['plate']));img.pack()
    bg=plane('BLANK PLATE — baked image',10,10*h/w,-0.02,image_material(sid+' plate',img),col);bg.hide_select=True
    empty=bpy.data.images.new(sid+' full-canvas artwork',width=w,height=h,alpha=True);empty.generated_color=(1,1,1,0);empty.pack()
    overlay=plane('ASSET — full-canvas transparent overlay',10,10*h/w,0.02,image_material(sid+' artwork',empty,True),art)
    overlay['instructions']='Supply a full-canvas transparent image with this scene native dimensions. This is not a UV-fitted physical surface. For local logos, scale/place a decal mesh or prepare a positioned canvas.'

notes=bpy.data.texts.new('START HERE')
notes.write('''30 new blank showcase plates\n\nChoose a scene from the Scene selector. Cameras and output aspect ratios match the generated plates.\nThese scenes are fixed-camera image plates. Objects, people, material and lighting are baked into each PNG.\nThe ARTWORK collection includes a transparent full-canvas overlay. Replace REPLACE_IMAGE in its material\nwith your positioned artwork canvas, or add and position local decal meshes manually.\nThe overlay is NOT a pre-fitted UV surface for every object in a packaging kit.\nKeep the camera fixed. Press F12 to render. Save a copy of this file before editing.\nUse source references and composition notes in the product-renders skill to position artwork.\n''')
bpy.context.window.scene=first
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            area.spaces.active.region_3d.view_perspective='CAMERA';area.spaces.active.shading.type='MATERIAL';area.spaces.active.overlay.show_overlays=False
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'expanded-plates.blend'))
print('BUILT',len(manifest['plates']),'fixed-camera plate scenes')
