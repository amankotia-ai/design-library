import bpy,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
folder=ROOT/'verification';folder.mkdir(exist_ok=True)
for scene in bpy.data.scenes:
    bpy.context.window.scene=scene
    w,h=scene.render.resolution_x,scene.render.resolution_y
    factor=480/max(w,h)
    scene.render.resolution_x=round(w*factor);scene.render.resolution_y=round(h*factor)
    scene.render.filepath=str(folder/(scene.name+'.png'))
    assert scene.camera and len(scene.objects)==3,scene.name
    bpy.ops.render.render(write_still=True)
print('Rendered',len(bpy.data.scenes),'plate scenes without changing the saved project')
