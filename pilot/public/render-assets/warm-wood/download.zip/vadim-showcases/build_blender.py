"""Run with Blender --background --python build_blender.py. Fixed photo plates."""
import bpy,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
data=json.loads((ROOT/'manifest.json').read_text())
for obj in list(bpy.data.objects):bpy.data.objects.remove(obj,do_unlink=True)
for s in list(bpy.data.scenes)[1:]:bpy.data.scenes.remove(s)
first=bpy.data.scenes[0]
SLOTS={
'vadim-phone-desk': [('screen',[(.282,.398),(.405,.254),(.700,.589),(.602,.734)],(1170,2532))],
'vadim-auditorium-display':[('display',[(.246,.297),(.756,.297),(.756,.690),(.246,.690)],(2400,1040))],
'vadim-five-social-cards':[(str(i+1),[(x/1672,288/941),((x+235)/1672,288/941),((x+235)/1672,652/941),(x/1672,652/941)],(1080,1672)) for i,x in enumerate([190,455,719,983,1247])],
'vadim-laptop-sticker':[('sticker',[(.449,.354),(.553,.449),(.517,.518),(.414,.423)],(1600,700))]
}

def mat(name,img,alpha=False):
 m=bpy.data.materials.new(name);m.use_nodes=True;n=m.node_tree.nodes;n.clear();l=m.node_tree.links
 t=n.new('ShaderNodeTexImage');t.image=img;t.name='REPLACE_IMAGE' if alpha else 'PACKED_PLATE';t.interpolation='Linear' if alpha else 'Closest'
 e=n.new('ShaderNodeEmission');l.new(t.outputs['Color'],e.inputs['Color']);o=n.new('ShaderNodeOutputMaterial')
 if alpha:
  tr=n.new('ShaderNodeBsdfTransparent');mix=n.new('ShaderNodeMixShader');l.new(t.outputs['Alpha'],mix.inputs[0]);l.new(tr.outputs[0],mix.inputs[1]);l.new(e.outputs[0],mix.inputs[2]);l.new(mix.outputs[0],o.inputs[0])
 else:l.new(e.outputs[0],o.inputs[0])
 return m

def quad(scene,name,corners,w,h,z,material):
 verts=[((x-.5)*10,(.5-y)*10*h/w,z) for x,y in corners]
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],[(0,1,2,3)]);mesh.update();uv=mesh.uv_layers.new()
 for loop,co in zip(uv.data,[(0,1),(1,1),(1,0),(0,0)]):loop.uv=co
 ob=bpy.data.objects.new(name,mesh);scene.collection.objects.link(ob);ob.data.materials.append(material);return ob

for i,r in enumerate(data['plates']):
 s=first if i==0 else bpy.data.scenes.new(r['id']);s.name=r['id'];bpy.context.window.scene=s
 w,h=r['generated_dimensions'];s.render.engine='CYCLES';s.cycles.samples=16;s.cycles.use_denoising=False;s.cycles.pixel_filter_type='BOX'
 s.render.resolution_x=w;s.render.resolution_y=h;s.render.resolution_percentage=100;s.render.image_settings.file_format='PNG';s.render.filepath='//renders/'+r['id']+'.png'
 s.view_settings.view_transform='Standard';s.view_settings.look='None';s['type']='Fixed-camera baked photographic plate, guide UV quads; no recovered object geometry'
 camera=bpy.data.cameras.new('Fixed camera');camera.type='ORTHO';camera.ortho_scale=10;camera.sensor_fit='HORIZONTAL';cam=bpy.data.objects.new('CAMERA — fixed',camera);s.collection.objects.link(cam);cam.location=(0,0,10);s.camera=cam
 image=bpy.data.images.load(str(ROOT/r['plate']));image.pack();bg=quad(s,'PLATE — baked lighting',[(0,0),(1,0),(1,1),(0,1)],w,h,-.05,mat(r['id']+' plate',image));bg.hide_select=True
 for label,corners,size in SLOTS[r['id']]:
  img=bpy.data.images.new(r['id']+' '+label+' art',width=size[0],height=size[1],alpha=True);img.generated_color=(1,1,1,0);img.pack()
  ob=quad(s,'ASSET — '+label,corners,w,h,0,mat(r['id']+' '+label,img,True));ob['usage']='Replace REPLACE_IMAGE. Inset guide; fit exact corners and masks for full bleed. Phone requires rounded/island mask. Baked illumination must be applied to physical ink.'
note=bpy.data.texts.new('START HERE');note.write('Four fixed-camera photographic plates and eight transparent guide artwork slots. Images packed. Replace REPLACE_IMAGE on ASSET objects. Guide quads require exact occlusion/corner masks for full bleed; they are not complete physical reconstructions. Keep camera fixed. See composition-notes.md and independent finishing QA. Lighting is baked into plate. Save a copy before editing.')
bpy.context.window.scene=first
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'vadim-plates.blend'))
print('BUILT 4 scenes, 8 guide slots')
