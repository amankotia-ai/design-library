"""Fit artwork to the exact two newly supplied blank photos, not an earlier library photo."""
from pathlib import Path
from PIL import Image,ImageFilter
import numpy as np,json,sys,shutil,hashlib
ROOT=Path(__file__).resolve().parent
from fit_surface import neutral,filled,fit_quad,island,polynomial_material
for name in ['reference','surfaces','renders','checks','qa']:(ROOT/name).mkdir(exist_ok=True)
jobs=[('sidequest-explore-forward','05-person-forward-phone','/var/folders/tx/z_rvf2qn2wz6sjz__fnlmmd40000gn/T/codex-clipboard-65260960-b1bc-4c12-b810-1f221eda10c4.png','sidequest-home',(475,410),(690,157),(645,113,739,198)),('sidequest-route-pov','06-pov-handheld-phone','/var/folders/tx/z_rvf2qn2wz6sjz__fnlmmd40000gn/T/codex-clipboard-97f862d6-0c61-4ba0-b63b-ad2936dc16f5.png','sidequest-route',(600,400),(600,103),(553,87,642,122))]
result=[]
for sid,oldid,attachment,art,seed,iseed,roi in jobs:
 dst=ROOT/'reference'/(sid+'-blank.png')
 if not dst.exists():shutil.copy2(attachment,dst)
 photo=Image.open(dst).convert('RGB');sx=photo.width/1199;sy=photo.height/898
 scale=lambda p:(round(p[0]*sx),round(p[1]*sy))
 rough=([[721.8482400159077,68.37077689964057],[978.1853905940704,268.7075170968338],[552.4925387441826,815.7642355573386],[301.28537133482854,622.9842483673691]] if oldid.startswith('05-') else [[579,103],[869,103],[869,722],[579,722]])
 raw=neutral(photo,scale(seed));outer=filled(raw);q,fit=fit_quad(outer,rough)
 ir=(round(roi[0]*sx),round(roi[1]*sy),round(roi[2]*sx),round(roi[3]*sy));physical=island(photo,ir,scale(iseed));mask=Image.fromarray(np.uint8(np.array(outer).astype(float)*(1-np.array(physical)/255))).filter(ImageFilter.GaussianBlur(.55));mask.save(ROOT/'surfaces'/(sid+'-mask.png'));physical.save(ROOT/'surfaces'/(sid+'-island.png'))
 field=np.array(polynomial_material(photo,raw)).astype(float);lum=field@np.array([.2126,.7152,.0722]);normal=np.percentile(lum[np.array(mask)>245],90);ratio=np.clip(lum/max(1,normal),.85,1);Image.fromarray(np.uint8(ratio*255)).save(ROOT/'surfaces'/(sid+'-lighting.png'))
 result.append({'id':sid,'size':list(photo.size),'blank':'reference/'+dst.name,'reference_sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'mask':'surfaces/'+sid+'-mask.png','lighting':'surfaces/'+sid+'-lighting.png','physical_island':'surfaces/'+sid+'-island.png','quad':q,'fit':fit,'artwork':'artwork/'+art+'.png','source_kind':'current_user_attachment','type':'Fixed-camera projective screen composition on exact provided photograph'})
(ROOT/'scenes.json').write_text(json.dumps({'concept':'Fictional Sidequest local-adventure app','scenes':result},indent=2)+'\n');print('Fitted2 current attachments; no previous physical photograph substituted.')
