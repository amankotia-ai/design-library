"""Editable SVG + matching sharp PNG UI for a fictional Sidequest app concept."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import html,math,json
ROOT=Path(__file__).resolve().parent;ART=ROOT/'artwork';ART.mkdir(parents=True,exist_ok=True)
INK='#20211e';PAPER='#f8f6ee';ORANGE='#ff6036';MUTED='#696b63';LINE='#deded3';WHITE='#fffdf7'
FONTS={'regular':'/System/Library/Fonts/Supplemental/Arial.ttf','bold':'/System/Library/Fonts/Supplemental/Arial Bold.ttf','black':'/System/Library/Fonts/Supplemental/Arial Black.ttf','brand':'/System/Library/Fonts/Supplemental/Arial Rounded Bold.ttf'}
class Canvas:
 def __init__(self,w=390,h=844,bg=PAPER,scale=3):
  self.w=w;self.h=h;self.s=scale;self.im=Image.new('RGBA',(w*scale,h*scale),bg);self.d=ImageDraw.Draw(self.im);self.parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{w*scale}" height="{h*scale}" viewBox="0 0 {w} {h}"><rect width="{w}" height="{h}" fill="{bg}"/>'];self.copy=[]
 def xy(self,box):return tuple(round(x*self.s)for x in box)
 def rect(self,x,y,w,h,fill=WHITE,r=0,stroke=None,sw=1):
  self.d.rounded_rectangle(self.xy((x,y,x+w,y+h)),radius=r*self.s,fill=fill,outline=stroke,width=round(sw*self.s));self.parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill or "none"}" stroke="{stroke or "none"}" stroke-width="{sw}"/>')
 def circle(self,x,y,r,fill=INK,stroke=None,sw=1):
  self.d.ellipse(self.xy((x-r,y-r,x+r,y+r)),fill=fill,outline=stroke,width=round(sw*self.s));self.parts.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill or "none"}" stroke="{stroke or "none"}" stroke-width="{sw}"/>')
 def line(self,points,color=INK,sw=2):
  self.d.line([self.xy(p)for p in points],fill=color,width=max(1,round(sw*self.s)),joint='curve');self.parts.append('<polyline points="'+' '.join(f'{x},{y}'for x,y in points)+f'" fill="none" stroke="{color}" stroke-width="{sw}" stroke-linejoin="round" stroke-linecap="round"/>')
 def polygon(self,points,fill=INK):
  self.d.polygon([self.xy(p)for p in points],fill=fill);self.parts.append('<polygon points="'+' '.join(f'{x},{y}'for x,y in points)+f'" fill="{fill}"/>')
 def text(self,x,y,text,size=14,weight='regular',fill=INK,align='left'):
  font=ImageFont.truetype(FONTS[weight],round(size*self.s));anchor={'left':'ls','center':'ms','right':'rs'}[align];self.d.text((x*self.s,y*self.s),text,font=font,fill=fill,anchor=anchor)
  family='Arial Rounded MT Bold'if weight=='brand'else('Arial Black'if weight=='black'else'Arial');bold='bold'if weight in ['bold','brand','black']else'normal';anc={'left':'start','center':'middle','right':'end'}[align]
  self.parts.append(f'<text x="{x}" y="{y}" font-family="{family},sans-serif" font-size="{size}" font-weight="{bold}" fill="{fill}" text-anchor="{anc}">{html.escape(text)}</text>');self.copy.append(text)
 def save(self,name):
  self.im.save(ART/(name+'.png'));(ART/(name+'.svg')).write_text('\n'.join(self.parts+['</svg>'])+'\n');return self.copy
def arrow(c,x,y,color=INK,sw=2,n=8):c.line([(x-n,y),(x+n,y)],color,sw);c.line([(x+2,y-6),(x+n,y),(x+2,y+6)],color,sw)
def star(c,x,y,r,fill=INK,face=False):
 points=[]
 for i in range(80):
  t=i*2*math.pi/80;rad=r*(.62+.38*math.cos(4*t));points.append((x+math.cos(t)*rad,y+math.sin(t)*rad))
 c.polygon(points,fill)
 if face:
  c.rect(x-r*.29,y-r*.13,r*.12,r*.26,WHITE,r*.06);c.rect(x+r*.17,y-r*.13,r*.12,r*.26,WHITE,r*.06);c.line([(x-r*.1,y+r*.22),(x,y+r*.27),(x+r*.12,y+r*.22)],WHITE,2)
def cup(c,x,y,color=INK):
 c.rect(x-9,y-7,16,15,None,3,color,1.8);c.line([(x+8,y-5),(x+13,y-5),(x+13,y+2),(x+8,y+2)],color,1.8);c.line([(x-11,y+11),(x+10,y+11)],color,1.8)
def camera(c,x,y,color=INK):
 c.rect(x-13,y-9,26,19,None,4,color,1.8);c.circle(x,y,5,None,color,1.8);c.line([(x-7,y-10),(x-5,y-14),(x+4,y-14),(x+6,y-10)],color,1.8)
def pin(c,x,y,color=INK):
 c.circle(x,y-4,7,None,color,1.8);c.line([(x-5,y+2),(x,y+10),(x+5,y+2)],color,1.8);c.circle(x,y-4,2,color)
def bookmark(c,x,y,color=INK):c.line([(x-7,y+10),(x-7,y-10),(x+7,y-10),(x+7,y+10),(x,y+5),(x-7,y+10)],color,1.8)
def status(c):
 c.text(32,30,'9:41',12,'bold')
 for x,h in [(316,4),(320,6),(324,9),(328,12)]:c.rect(x,27-h,2,h,INK,r=.5)
 c.line([(337,19),(341,17),(345,19)],INK,1.5);c.line([(338,22),(341,20),(344,22)],INK,1.5);c.circle(341,25,1,INK);c.rect(353,17,18,10,None,3,INK,1);c.rect(355,19,13,6,INK,1);c.rect(372,20,2,4,INK,1)
def home_indicator(c):c.rect(133,827,124,4,INK,r=2)
def home():
 c=Canvas();status(c);star(c,35,82,12,ORANGE);c.text(55,91,'sidequest',26,'brand');c.circle(346,81,19,INK);c.text(346,86,'J',14,'bold',PAPER,'center')
 c.text(22,153,'Go find your',42,'bold');c.text(22,201,'plot twist.',42,'bold');c.text(24,233,'Your city. A little less ordinary.',14,fill=MUTED)
 c.rect(20,264,350,284,ORANGE,26);c.text(42,297,'PICKED FOR YOU',10,'bold');c.text(42,342,'Take the',30,'bold');c.text(42,377,'scenic route.',30,'bold')
 # A meandering trail and a curious character make the hero more than a text tile.
 pts=[]
 for i in range(100):
  t=i/99;pts.append((281+35*math.sin(t*math.pi*2),405+104*t))
 c.line(pts,PAPER,4);c.circle(281,509,7,PAPER);c.circle(281,509,3,ORANGE);star(c,290,370,43,INK,True)
 c.text(42,420,'A new way to get nowhere.',12);c.rect(40,468,163,36,PAPER,18);c.text(121.5,491,'15 min  ·  0.8 km',12,'bold',align='center');c.circle(336,513,17,INK);arrow(c,336,513,PAPER,1.8,6)
 c.text(22,589,'Quick detours',20,'bold');c.text(368,588,'See all',12,fill=MUTED,align='right')
 c.rect(20,609,169,123,WHITE,18,LINE);c.rect(201,609,169,123,WHITE,18,LINE)
 camera(c,47,636);c.text(35,677,'Find a new angle',14,'bold');c.text(35,703,'Photo walk · 10 min',11,fill=MUTED)
 cup(c,230,636);c.text(216,677,'Break the routine',14,'bold');c.text(216,703,'Coffee quest · 15 min',11,fill=MUTED)
 c.line([(20,758),(370,758)],LINE,1)
 pin(c,77,784,ORANGE);c.text(77,814,'Explore',10,'bold',INK,'center');bookmark(c,195,784,MUTED);c.text(195,814,'Saved',10,fill=MUTED,align='center');c.circle(313,778,5,None,MUTED,1.7);c.line([(303,794),(305,787),(321,787),(323,794)],MUTED,1.7);c.text(313,814,'You',10,fill=MUTED,align='center');home_indicator(c)
 return c.save('sidequest-home')
def detail():
 c=Canvas();status(c);c.circle(42,80,20,WHITE,LINE);c.line([(47,73),(40,80),(47,87)],INK,2);c.text(195,84,'TODAY\u2019S DETOUR',11,'bold',align='center');c.circle(348,80,20,WHITE,LINE);bookmark(c,348,80)
 c.text(22,153,'The long',44,'bold');c.text(22,203,'way home.',44,'bold');c.text(24,235,'A coffee. A corner. A good story.',14,fill=MUTED)
 c.rect(20,265,350,278,'#e7e7dc',25)
 for b in [(41,285,76,57),(136,285,58,57),(214,285,61,57),(295,285,55,57),(41,361,76,52),(136,361,58,52),(214,361,61,52),(295,361,55,52),(41,432,76,60),(136,432,58,60),(214,432,61,60),(295,432,55,60)]:c.rect(*b,'#f4f3e8',7)
 c.text(310,307,'N',10,'bold',fill=MUTED);c.line([(312,315),(312,326)],MUTED,1.5)
 c.text(154,318,'PARKSIDE',8,'bold',fill=MUTED,align='center');c.text(300,471,'WILLOW ST.',7,fill=MUTED)
 # Simplified illustrative map; routes and distances are fictional concept content.
 c.line([(78,468),(78,422),(204,422),(204,352),(291,352),(291,318)],ORANGE,7)
 c.circle(78,468,13,INK);c.text(78,472,'1',11,'bold',PAPER,'center');c.circle(204,390,15,PAPER);cup(c,204,390,INK);c.circle(291,318,15,ORANGE);star(c,291,318,9,PAPER)
 c.rect(46,500,298,27,WHITE,14);c.text(195,518,'15 min     ·     0.8 km     ·     3 tiny stops',11,'bold',align='center')
 c.text(24,578,'GOOD THINGS ALONG THE WAY',10,'bold',fill=MUTED)
 c.rect(24,596,38,38,INK,12);cup(c,43,614,PAPER);c.text(76,610,'Try a new coffee spot',15,'bold');c.text(76,630,'Your usual. Somewhere unusual.',11,fill=MUTED)
 c.line([(76,649),(366,649)],LINE,1)
 c.rect(24,666,38,38,INK,12);pin(c,43,682,PAPER);c.text(76,680,'Follow the quiet street',15,'bold');c.text(76,700,'Take a turn you normally wouldn\u2019t.',11,fill=MUTED)
 c.rect(20,738,350,58,ORANGE,29);c.text(177,773,'Let\u2019s take a detour',16,'bold',align='center');arrow(c,334,768,INK,2,7);home_indicator(c)
 return c.save('sidequest-route')
copy={'home':home(),'route':detail()}
c=Canvas(128,128,ORANGE,4);star(c,64,64,44,INK,True);c.save('sidequest-icon')
(ART/'copy.json').write_text(json.dumps({'concept':'Fictional Sidequest app: small neighborhood adventures. Illustrative map,distances and recommendations are demo content.','screens':copy},indent=2)+'\n')
preview=Image.new('RGB',(900,1060),'#e9e7df');d=ImageDraw.Draw(preview)
for i,name in enumerate(['sidequest-home','sidequest-route']):
 im=Image.open(ART/(name+'.png')).convert('RGB');im.thumbnail((390,900));preview.paste(im,(35+440*i,90));font=ImageFont.truetype(FONTS['bold'],23);d.text((35+440*i,30),'Explore'if i==0 else'Quest detail',font=font,fill=INK)
preview.save(ROOT/'app-screens-preview.jpg',quality=95)
print('Created two complete UI states,editableSVGs,sharpPNGs and app icon.')
