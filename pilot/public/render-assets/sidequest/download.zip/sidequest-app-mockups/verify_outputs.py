"""Verify saved-source replay and changes confined to the supplied screen masks."""
from pathlib import Path
from PIL import Image,ImageFilter
import numpy as np,json,hashlib
ROOT=Path(__file__).resolve().parent
records=json.loads((ROOT/'scenes.json').read_text())['scenes'];results=[]
for record in records:
 sid=record['id'];p=ROOT/'renders'/(sid+'.png');a=np.array(Image.open(p).convert('RGB')).astype(int);b=np.array(Image.open(ROOT/'checks'/(sid+'-blank.png')).convert('RGB')).astype(int);c=np.array(Image.open(ROOT/'checks'/(sid+'-reopened.png')).convert('RGB')).astype(int);mask=Image.open(ROOT/record['mask']);outside=np.array(mask.filter(ImageFilter.MaxFilter(5)))==0
 assert np.array_equal(a,c),sid
 assert not np.any((a-b)[outside]),sid
 assert hashlib.sha256((ROOT/record['blank']).read_bytes()).hexdigest()==record['reference_sha256']
 source=np.array(Image.open(ROOT/record['blank']).convert('RGB')).astype(int);delta=abs(b-source)
 results.append({'id':sid,'render_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'dimensions':list(Image.open(p).size),'reopened_decoded_pixels_identical':True,'branded_vs_blender_blank_outside_2px_mask_maxdiff':int(abs(a-b)[outside].max()),'blender_blank_vs_reference_mean_abs_255':float(delta.mean()),'note':'Blender source-color rounding/sampling differs minutely from canonical photograph; no extra changes outside screen compared with Blender blank.'})
(ROOT/'checks/replay-verification.json').write_text(json.dumps({'status':'pass','results':results},indent=2)+'\n')
print('PASS:both saved-source renders reproduce exactly;screen replacement changes no pixels outside expanded physical masks versus Blender blanks.')
