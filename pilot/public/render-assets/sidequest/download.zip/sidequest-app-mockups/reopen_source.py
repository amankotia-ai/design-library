from pathlib import Path
import bpy,json
ROOT=Path(__file__).resolve().parent
assert len(bpy.data.scenes)==2
for image in bpy.data.images:
 if image.source=='FILE':assert image.packed_file,image.name
for scene in bpy.data.scenes:
 scene.render.filepath=str(ROOT/'checks'/(scene.name+'-reopened.png'));bpy.ops.render.render(write_still=True,scene=scene.name)
(ROOT/'checks/reopened-structure.json').write_text(json.dumps({'scene_count':2,'all_file_images_packed':True,'saved_source':'sidequest-mockups.blend'},indent=2)+'\n')
