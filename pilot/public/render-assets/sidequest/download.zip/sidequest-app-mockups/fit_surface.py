"""Native screen fitting helpers, shared with the reviewed mobile template workflow."""

from PIL import Image,ImageDraw,ImageFilter

import numpy as np

def cc(binary,seed):
 m=Image.fromarray(np.uint8(binary)*255).copy();assert m.getpixel(tuple(seed))==255,('bad seed',seed)
 ImageDraw.floodfill(m,tuple(seed),128);return Image.fromarray(np.uint8(np.array(m)==128)*255)

def filled(m):
 a=np.array(m);inv=Image.fromarray(255-a).copy();ImageDraw.floodfill(inv,(0,0),128);return Image.fromarray(np.uint8((a>0)|(np.array(inv)==255))*255)

def neutral(photo,seed,minimum=130,delta=45,roi=None):
 a=np.array(photo.convert('RGB')).astype(float);ok=(a.min(2)>minimum)&(a.max(2)-a.min(2)<delta)
 if roi:
  region=np.zeros(ok.shape,bool);x1,y1,x2,y2=roi;region[y1:y2,x1:x2]=1;ok&=region
 return cc(ok,seed)

def hull(mask):
 a=np.array(mask)>0;inner=a.copy();inner[1:]&=a[:-1];inner[:-1]&=a[1:];inner[:,1:]&=a[:,:-1];inner[:,:-1]&=a[:,1:]
 yy,xx=np.where(a&~inner);pts=sorted(set(zip(xx.tolist(),yy.tolist())))
 def cross(o,a,b):return(a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
 lo=[];hi=[]
 for p in pts:
  while len(lo)>1 and cross(lo[-2],lo[-1],p)<=0:lo.pop()
  lo.append(p)
 for p in reversed(pts):
  while len(hi)>1 and cross(hi[-2],hi[-1],p)<=0:hi.pop()
  hi.append(p)
 m=Image.new('L',mask.size);ImageDraw.Draw(m).polygon(lo[:-1]+hi[:-1],fill=255);return m

def fit_quad(mask,rough):
 a=np.array(mask)>0;inside=a.copy();inside[1:]&=a[:-1];inside[:-1]&=a[1:];inside[:,1:]&=a[:,:-1];inside[:,:-1]&=a[:,1:]
 yy,xx=np.where(a&~inside);edge=np.column_stack([xx,yy]).astype(float);lines=[];rng=np.random.default_rng(7302026);diag=[]
 for i in range(4):
  p=np.array(rough[i],float);q=np.array(rough[(i+1)%4],float);v=q-p;length=np.linalg.norm(v);v/=length;n=np.array([-v[1],v[0]]);rel=edge-p;t=rel@v/length
  pts=edge[(t>.14)&(t<.86)&(np.abs(rel@n)<50)];assert len(pts)>20,('too few edge points',i,len(pts))
  best=None;score=0
  for _ in range(200):
   p1,p2=pts[rng.choice(len(pts),2,replace=False)];vv=p2-p1;ll=np.linalg.norm(vv)
   if ll<length*.2:continue
   nn=np.array([-vv[1],vv[0]])/ll;dd=-(nn@p1);keep=np.abs(pts@nn+dd)<.75
   if keep.sum()>score:score=keep.sum();best=keep
  assert best is not None
  pp=pts[best];center=pp.mean(0);_,_,V=np.linalg.svd(pp-center,full_matrices=False);nn=V[-1];dd=-(nn@center);lines.append((nn,dd));diag.append({'edge':i,'inliers':len(pp),'rms':float(np.sqrt(np.mean((pp@nn+dd)**2)))})
 out=[]
 for i in range(4):
  n1,d1=lines[(i-1)%4];n2,d2=lines[i];out.append(np.linalg.solve(np.stack([n1,n2]),-np.array([d1,d2])).tolist())
 return out,diag

def polynomial_material(photo,mask):
 a=np.array(photo.convert('RGB'));yy,xx=np.where(np.array(mask)>220);assert len(xx)>100
 step=max(1,len(xx)//16000);xx=xx[::step];yy=yy[::step];x=xx/photo.width;y=yy/photo.height
 A=np.column_stack([np.ones(len(x)),x,y,x*x,x*y,y*y]);coeff=np.linalg.lstsq(A,a[yy,xx],rcond=None)[0]
 gy,gx=np.mgrid[:photo.height,:photo.width];gx=gx/photo.width;gy=gy/photo.height
 result=np.zeros(a.shape,float)
 for i,basis in enumerate([np.ones_like(gx),gx,gy,gx*gx,gx*gy,gy*gy]):result+=basis[:,:,None]*coeff[i]
 med=np.median(a[yy,xx],axis=0);result=np.clip(result,np.maximum(0,med-45),np.minimum(255,med+45))
 return Image.fromarray(np.uint8(np.clip(result,0,255)))

def island(photo,roi,seed):
 a=np.array(photo.convert('RGB')).astype(float);ok=a.mean(2)<105;region=np.zeros(ok.shape,bool);x1,y1,x2,y2=roi;region[y1:y2,x1:x2]=1
 m=hull(filled(cc(ok&region,seed)));return m.filter(ImageFilter.GaussianBlur(.5))

