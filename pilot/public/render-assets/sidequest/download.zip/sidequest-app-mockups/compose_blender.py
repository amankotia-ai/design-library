"""Build two actual branded Blender compositions with packed source photos and artwork."""
from pathlib import Path
import bpy,json,numpy as np
ROOT=Path(__file__).resolve().parent;data=json.loads((ROOT/'scenes.json').read_text());initial=list(bpy.data.scenes)
for ob in list(bpy.data.objects):bpy.data.objects.remove(ob,do_unlink=True)
def img(path,noncolor=False):
 i=bpy.data.images.load(str(ROOT/path));i.pack();i.use_fake_user=True
 if noncolor:i.colorspace_settings.name='Non-Color'
 return i
def surface(scene,name,q,W,H,z,divisions=1,overdraw=0):
 A=[];b=[]
 for(u,v),(x,y)in zip([(0,0),(1,0),(1,1),(0,1)],q):
  A.extend([[u,v,1,0,0,0,-u*x,-v*x],[0,0,0,u,v,1,-u*y,-v*y]]);b.extend([x,y])
 matrix=np.append(np.linalg.solve(np.array(A,float),np.array(b,float)),1).reshape(3,3);verts=[];uv=[];faces=[]
 for j in range(divisions+1):
  for i in range(divisions+1):
   u=-overdraw+(1+2*overdraw)*i/divisions;v=-overdraw+(1+2*overdraw)*j/divisions;p=matrix@np.array([u,v,1]);x,y=p[:2]/p[2];verts.append(((x/W-.5)*10,(.5-y/H)*10*H/W,z));uv.append((u,1-v))
 for j in range(divisions):
  for i in range(divisions):
   k=j*(divisions+1)+i;faces.append((k,k+1,k+divisions+2,k+divisions+1))
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update();layer=mesh.uv_layers.new(name='Fitted projective UV')
 for poly in mesh.polygons:
  for li in poly.loop_indices:layer.data[li].uv=uv[mesh.loops[li].vertex_index]
 ob=bpy.data.objects.new(name,mesh);scene.collection.objects.link(ob);return ob
for record in data['scenes']:
 sid=record['id'];W,H=record['size'];scene=bpy.data.scenes.new(sid);scene['type']=record['type'];scene['concept']='Sidequest fictional app UI; map,distances and recommendations are demonstration content.'
 scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False;scene.cycles.pixel_filter_type='BOX';scene.render.resolution_x=W;scene.render.resolution_y=H;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='Standard';scene.view_settings.look='None'
 camera=bpy.data.cameras.new(sid+' fixed camera');camera.type='ORTHO';camera.ortho_scale=10;camera.sensor_fit='HORIZONTAL';cam=bpy.data.objects.new('CAMERA — keep fixed',camera);scene.collection.objects.link(cam);cam.location=(0,0,10);scene.camera=cam
 m=bpy.data.materials.new(sid+' photograph');m.use_nodes=True;n=m.node_tree.nodes;n.clear();l=m.node_tree.links;t=n.new('ShaderNodeTexImage');t.image=img(record['blank']);t.interpolation='Closest';em=n.new('ShaderNodeEmission');out=n.new('ShaderNodeOutputMaterial');l.new(t.outputs['Color'],em.inputs['Color']);l.new(em.outputs[0],out.inputs[0]);ob=surface(scene,'PLATE — exact current attachment',[(0,0),(W,0),(W,H),(0,H)],W,H,-.05);ob.data.materials.append(m);ob.hide_select=True
 m=bpy.data.materials.new(sid+' screen');m.use_nodes=True;n=m.node_tree.nodes;n.clear();l=m.node_tree.links;coord=n.new('ShaderNodeTexCoord');coord.location=(-1000,-300);art=n.new('ShaderNodeTexImage');art.name='REPLACE_IMAGE';art.label='Sidequest UI — replace to make a variant';art.image=img(record['artwork']);art.extension='EXTEND';art.location=(-1000,200)
 mask=n.new('ShaderNodeTexImage');mask.name='PHYSICAL_MASK — camera and fingers';mask.image=img(record['mask'],True);mask.extension='CLIP';mask.location=(-750,-200);l.new(coord.outputs['Window'],mask.inputs['Vector']);light=n.new('ShaderNodeTexImage');light.name='BAKED_RELATIVE_ILLUMINATION';light.image=img(record['lighting'],True);light.location=(-750,-450);l.new(coord.outputs['Window'],light.inputs['Vector']);color=n.new('ShaderNodeMixRGB');color.blend_type='MULTIPLY';color.inputs[0].default_value=1;color.location=(-400,200);l.new(art.outputs['Color'],color.inputs[1]);l.new(light.outputs['Color'],color.inputs[2]);alpha=n.new('ShaderNodeMath');alpha.operation='MULTIPLY';l.new(art.outputs['Alpha'],alpha.inputs[0]);l.new(mask.outputs['Color'],alpha.inputs[1]);vis=n.new('ShaderNodeMath');vis.name='ARTWORK_VISIBILITY';vis.operation='MULTIPLY';vis.inputs[1].default_value=1;l.new(alpha.outputs[0],vis.inputs[0]);em=n.new('ShaderNodeEmission');em.location=(-100,200);l.new(color.outputs[0],em.inputs['Color']);tr=n.new('ShaderNodeBsdfTransparent');mix=n.new('ShaderNodeMixShader');mix.location=(150,100);l.new(vis.outputs[0],mix.inputs[0]);l.new(tr.outputs[0],mix.inputs[1]);l.new(em.outputs[0],mix.inputs[2]);out=n.new('ShaderNodeOutputMaterial');out.location=(400,100);l.new(mix.outputs[0],out.inputs[0]);ob=surface(scene,'ASSET — '+sid+' UI',record['quad'],W,H,.01,64,.01);ob.data.materials.append(m);ob['artwork_canvas']='1170x2532 portrait UI; camera island is already physical'
 scene.render.filepath='//renders/'+sid+'.png'
bpy.context.window.scene=bpy.data.scenes[data['scenes'][0]['id']]
for scene in initial:bpy.data.scenes.remove(scene)
notes=bpy.data.texts.new('START HERE');notes.write('Sidequest is a fictional local-adventure app concept. Two complete UI states on the exact two current user-provided blank photos. Fixed-camera projective screen overlays; no recovered person/device geometry. Original screen illumination is baked and masks preserve camera/fingers. All source photos/UI/masks are packed. Choose scene,select ASSET,load art in REPLACE_IMAGE. Current master is already branded. Editable SVG/PNG artwork is beside this file. Keep artwork1170x2532 and do not add another camera/device frame. Save a copy and independently check every changed result.')
for ui in bpy.data.screens:
 for area in ui.areas:
  if area.type=='VIEW_3D':area.spaces.active.region_3d.view_perspective='CAMERA';area.spaces.active.shading.type='MATERIAL'
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'sidequest-mockups.blend'),compress=True)
for record in data['scenes']:
 scene=bpy.data.scenes[record['id']];scene.render.filepath=str(ROOT/'renders'/(scene.name+'.png'));bpy.ops.render.render(write_still=True,scene=scene.name)
 node=next(m.node_tree.nodes['ARTWORK_VISIBILITY']for m in bpy.data.materials if m.use_nodes and m.name==scene.name+' screen');node.inputs[1].default_value=0;scene.render.filepath=str(ROOT/'checks'/(scene.name+'-blank.png'));bpy.ops.render.render(write_still=True,scene=scene.name);node.inputs[1].default_value=1
print('Rendered two actual Sidequest compositions. Saved master remains branded and fully packed.')
