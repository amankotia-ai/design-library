"""Package only after exact independent QA acceptance, without changing reviewed files."""
from pathlib import Path
import json,hashlib,zipfile
ROOT=Path(__file__).resolve().parent
indexpath=ROOT/'qa/final-qa-index.json';index=json.loads(indexpath.read_text());assert index['status']=='pass'and len(index['reports'])==2
accepted={}
def pin(path,sha):
 p=Path(path);rel=p.relative_to(ROOT).as_posix();assert hashlib.sha256(p.read_bytes()).hexdigest()==sha,rel
 if rel in accepted:assert accepted[rel]==sha
 accepted[rel]=sha
def walk(x):
 if isinstance(x,dict):
  if 'file'in x and 'sha256'in x:pin(x['file'],x['sha256'])
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
walk(index);pin(indexpath,hashlib.sha256(indexpath.read_bytes()).hexdigest())
for r in index['reports']:
 assert r['status']=='pass';report=json.loads(Path(r['report']['file']).read_text());assert report['status']=='pass';walk(report)
assert json.loads((ROOT/'checks/isolated-surface-rebuild.json').read_text())['status']=='pass'
delivery={'status':'pass','concept':'Fictional Sidequest local-adventure app','finals':[{'file':Path(r['final']['file']).relative_to(ROOT).as_posix(),'sha256':r['final']['sha256']}for r in index['reports']],'native_size':[1449,1085],'source':'sidequest-mockups.blend','artwork_size':[1170,2532],'type':'Fixed-camera screen composites on exact supplied photographs','qa':'qa/final-qa-index.json','accepted_files':[{'file':p,'sha256':h}for p,h in sorted(accepted.items())]}
(ROOT/'delivery.json').write_text(json.dumps(delivery,indent=2)+'\n')
archive=ROOT.parent/'sidequest-app-mockups.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in sorted(ROOT.rglob('*')):
  if p.is_file()and '__pycache__'not in p.parts and p.suffix not in {'.blend1','.log','.pyc'}:z.write(p,ROOT.name+'/'+p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 for p,h in accepted.items():assert hashlib.sha256(z.read(ROOT.name+'/'+p)).hexdigest()==h,p
print(json.dumps({'archive':str(archive),'MiB':archive.stat().st_size/1048576,'independently_pinned_files':len(accepted),'zip_content_hashes_verified':True},indent=2))
